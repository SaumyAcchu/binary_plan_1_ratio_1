<?php
class Comm extends CI_Model
{
	public function downLineSingle($param1='',$param2='')
	{
		$id=$param1;
		$res1=$this->dbm->globalSelect('users',['place_id'=>$id,'place'=>$param2]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][$id][]=$value;
				$this->downLineSingle($value['user_id'],$param2);
			}
		}
	}

	public function downLine($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['sponcer_id'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][$id][]=$value;
				$this->downLine($value['user_id']);
			}
		}
	}
	public function downLineTree($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['parent'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][$id][]=$value;
				$this->downLineTree($value['user_id']);
			}
		}
	}

	public function downList($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['sponcer_id'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value;
				$this->downList($value['user_id']);
			}
		}
	}
		public function downListRR($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['parent'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value;
				$this->downListRR($value['user_id']);
			}
		}
	}

	public function downLineUser($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['sponcer_id'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value['user_id'];
				$this->downLineUser($value['user_id']);
			}
		}
	}
	public function downLineUserMatch($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['parent'=>$id,'status'=>1]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value['user_id'];
				$this->downLineUserMatch($value['user_id']);
			}
		}
	}
		public function downLineUserL($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['parent'=>$id,'place'=>"Left"]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value['user_id'];
				$this->downLineUserL($value['user_id']);
			}
		}
	}
	
		public function downLineUserR($param1='',$param2='')
	{
		$id=$param1;

		$res1=$this->dbm->globalSelect('users',['parent'=>$id,'place'=>"Right"]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value['user_id'];
				$this->downLineUserR($value['user_id']);
			}
		}
	}

	public function downLinePair($param1='',$param2='')
	{
		$id=$param1;
		$res1=$this->dbm->globalSelect('users',['place_id'=>$id]);
		if(!empty($res1))
		{
			foreach ($res1 as $key => $value)
			{
				$_SESSION['dList'][]=$value;
				$this->downLinePair($value['user_id']);
			}
		}
	}





	public function downLeft($param1='',$param2='')
	{
		$downLeft=[];
		$ass=$this->dbm->getWhere('users',['sponcer_id'=>$param1,'place'=>'Left']);
	    if($ass)
	    {
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$res=$this->downLine($ass['user_id']);
			$arr=$_SESSION['dList'];
			if(!empty($arr))
			{
				sort($arr);
				foreach ($arr as $key => $value)
				{
					foreach ($value as $key => $val)
					{
						$downLeft[]=$val;
					}
				}
			}
			array_unshift($downLeft, $ass);
		}
		return $downLeft;
	}

	public function downRight($param1='',$param2='')
	{
		$downRight=[];
		$assR=$this->dbm->getWhere('users',['sponcer_id'=>$param1,'place'=>'Right']);
		//echo "<pre>"; print_r($param1); die;
	    if($assR)
	    {
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$res=$this->downLine($assR['user_id']);
			$arr=$_SESSION['dList'];
			if(!empty($arr))
			{
				sort($arr);
				foreach ($arr as $key => $value)
				{
					foreach ($value as $key => $val)
					{
						$downRight[]=$val;
					}
				}
			}
			array_unshift($downRight, $assR);
		}
		return $downRight;
	}
	public function tds($data='')
	{
	    	$deduction['tds']=($data['amount']*0)/100;
			$deduction['admin']=($data['amount']*0)/100;
			$deduction['user_id']=$data['user_id'];
			$deduction['date']=date('Y-m-d');
			$deduction['time']=date('H:i:s');
			$deduction['amount']=$data['amount'];
			$deduction['type']=$data['type'];
			$deduction['status']=$data['status'];
			$left=($data['amount']-($deduction['admin']+$deduction['tds']));
            $this->db->insert('tds',$deduction);
            $usr=$this->dbm->getWhere('users',['user_id'=>$data['user_id']]);
            $wall=$left+$usr['wallet'];
		    $this->dbm->globalUpdate('users',['user_id'=>$usr['user_id']],['wallet'=>$wall]);
	    
	}

	public function repurchase_incom()
	{
	  $result=$this->dbm->globalSelect('users',['access'=>"limited",'status'=>1,'product!='=>11]);
     	    foreach ($result as $key => $value) {
     	 	   $this->RepurchageCommission($value['user_id']);
      	   	}
		
	}

	public function agentCommission($data='')
	{
	    $pinType= $this->dbm->getWhere('pin',['pin'=>$data['pin']]);
	    $productAmt = $this->dbm->getWhere('product_plan',['id'=>$pinType['product_id']]);
		$this->db->where(['pin'=>$data['pin']])->update('pin',['status'=>1,'activated_account'=>$data['user_id'],'date'=>date('Y-m-d'),'time'=>date('H:i:s')]);
		$this->db->where(['user_id'=>$data['user_id']])->update('users',['status'=>1,'active_date'=>date('Y-m-d'),'active_time'=>date('H:i:s'),'activated'=>date("Y-m-d H:i:s"),'topup'=>$productAmt['binary'],'product'=>$pinType['product_id']]);
		$this->allIndia();
        $this->Spon_incom();
		}

    	public function allIndia()
	{
		$j=0; $k=1; $pre=2; $max=0; $jump=3;$mul=3;
		$lvl=$this->dbm->globalSelect('level',['type'=>'india']);
		$leader=$this->dbm->globalSelect('users',['status'=>1,'access'=>'limited']);
		$down=count($leader)-1;
		foreach($lvl as $key => $value)
		{
			$max=$max+$value['team'];
			$j=$j+$value['team'];
			$max=$j;
			foreach ($leader as $key => $val)
			{
				if($down>=$max)
				{
					$row=$this->dbm->rowCount('india_income',['user_id'=>$val['user_id'],'level'=>$value['level']]);
					if($row<1)
					{
						$user=$this->db->get_where('users',['user_id'=>$val['user_id']])->row_array();
						$dir=$this->dbm->rowCount('users',['sponcer_id'=>$val['user_id'],'status'=>1]);
						$bonus['bonus']=$value['bonus'];
						if($user['pan']=='')
						{ $tds=0; }else{ $tds=0; }
						$pair = $this->reward->countSelfPair($val['user_id']);
						$deduction['tds']=($bonus['bonus']*$tds)/100;
						$deduction['admin']=($bonus['bonus']*0)/100;
						$deduction['user_id']=$user['user_id'];
						$deduction['date']=date('Y-m-d');
						$deduction['time']=date('H:i:s');
						$deduction['amount']=$bonus['bonus'];
						$deduction['type']='AUTOPOOL';
						$deduction['admin_percent']=0;
						$deduction['tds_percent']=$tds;
						$left=($bonus['bonus']-($deduction['admin']+$deduction['tds']));
						$data['down']=$down;
						$data['direct']=$dir;
						if($user['status']==1 && $dir>=$value['direct'] && $pair>=$value['pair'])
						{
							$data['status']=1;
							$deduction['status']=1;
							$data['is_credit']=1;
							$deduction['is_credit']=1;
							$wall=$left+$user['wallet'];
							$this->dbm->globalUpdate('users',['user_id'=>$user['user_id']],['wallet'=>$wall]);
						}else
						{
							$data['status']=0;
							$deduction['status']=0;
							$data['is_credit']=0;
							$deduction['is_credit']=0;
						}
						$data['user_id']=$val['user_id'];
						$data['level']=$value['level'];
						$data['amount']=(($bonus['bonus'])-($deduction['admin']+$deduction['tds']));
						$data['date']=date('Y-m-d');
						$data['time']=date('H:i:s');
						$trncId=$this->dbm->transactionNumber();
						$data['transaction']='I'.$trncId;
						$deduction['transaction']=$data['transaction'];
						$this->db->insert('india_income',$data);
						$this->db->insert('tds',$deduction);
					}
				}
				$max=$max+$jump;
				$k=$k+$pre;
			}
			$max=$value['team'];
			$k=$j+1;
			$pre=$pre*$mul;
			$jump=$jump*$mul;
		}
	}
	

	public function autoPayout()
	{
			$check=$this->dbm->rowCount('india_income',['credited'=>date('Y-m-d')]);
			if($check<1)
			{
				$allIndiaB=$this->dbm->globalSelect('india_income',['status'=>0,'is_credit'=>0]);
			 foreach ($allIndiaB as $key => $indiaB)
			{
			  $user=$this->dbm->getWhere('users',['user_id'=>$indiaB['user_id'],'status'=>1]);
				if($user){
				$level = $this->dbm->getWhere('level',['level'=>$indiaB['level']]);
				$dir=$this->dbm->rowCount('users',['sponcer_id'=>$indiaB['user_id'],'status'=>1]);
				$pair = $this->reward->countSelfPair($indiaB['user_id']);
				if ($dir>=$level['direct'] && $pair>=$level['pair']) {
					$arr2['wallet']=$user['wallet']+$indiaB['amount'];
					$this->dbm->globalUpdate('users',['user_id'=>$user['user_id']],$arr2);
					$this->dbm->globalUpdate('india_income',['id'=>$indiaB['id']],['is_credit'=>1,'status'=>1,'credited'=>date('Y-m-d')]);}
					}
				}
			}
		}

	public function selfTeam($param1='',$param2='')
	{
		$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$param1]);
		$arr=[];
		if(count($rec)>0)
		{
			$data[2]=[];$data[3]=[];$data[3]=[];$data[4]=[];$data[5]=[];$data[6]=[];$data[7]=[];$data[8]=[];$data[9]=[];$data[10]=[];$data[11]=[];$data[12]=[];
			$arr[2]=[];$arr[3]=[];$arr[3]=[];$arr[4]=[];$arr[5]=[];$arr[6]=[];$arr[7]=[];$arr[8]=[];$arr[9]=[];$arr[10]=[];$arr[11]=[];$arr[12]=[];
			$data[1][]=array_column($rec, 'user_id');
			$arr[1][]=$rec;
			if(count($data[1])>0)
			{
				foreach ($data[1] as $key => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$val]);
						if(count($rec)>0)
						{
							$data[2][]=array_column($rec, 'user_id');
							$arr[2][]=$rec;
						}
					}
				}
			}
			
			if(count($data[2])>0)
			{
				foreach ($data[2] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[3][]=array_column($rec, 'user_id');
							$arr[3][]=$rec;
						}
					}					
				}
			}
			if(count($data[3])>0)
			{
				foreach ($data[3] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[4][]=array_column($rec, 'user_id');
							$arr[4][]=$rec;
						}
					}					
				}
			}
			if(count($data[4])>0)
			{
				foreach ($data[4] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[5][]=array_column($rec, 'user_id');
							$arr[5][]=$rec;
						}
					}					
				}
			}
			if(count($data[5])>0)
			{
				foreach ($data[5] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[6][]=array_column($rec, 'user_id');
							$arr[6][]=$rec;
						}
					}					
				}
			}
			if(count($data[6])>0)
			{
				foreach ($data[6] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[7][]=array_column($rec, 'user_id');
							$arr[7][]=$rec;
						}
					}					
				}
			}
			if(count($data[7])>0)
			{
				foreach ($data[7] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[8][]=array_column($rec, 'user_id');
							$arr[8][]=$rec;
						}
					}					
				}
			}
			if(count($data[8])>0)
			{
				foreach ($data[8] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[9][]=array_column($rec, 'user_id');
							$arr[9][]=$rec;
						}
					}					
				}
			}
			if(count($data[9])>0)
			{
				foreach ($data[9] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[10][]=array_column($rec, 'user_id');
							$arr[10][]=$rec;
						}
					}					
				}
			}
			if(count($data[10])>0)
			{
				foreach ($data[10] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[11][]=array_column($rec, 'user_id');
							$arr[11][]=$rec;
						}
					}					
				}
			}
			if(count($data[11])>0)
			{
				foreach ($data[11] as $key1 => $value)
				{
					foreach ($value as $key => $val)
					{
						$rec=$this->dbm->globalSelect('users',['sponcer_id'=>$value[$key]]);
						if(count($rec)>0)
						{
							$data[12][]=array_column($rec, 'user_id');
							$arr[12][]=$rec;
						}
					}					
				}
			}
		}else
		{
			$data=[];
		}
		return $arr;
	}
	
	public function countDownR($param='')
	{
		$right=[]; 
		unset($_SESSION['dList']);
		$_SESSION['dList']=[];
		$id= $param;
		$ru=$this->dbm->getWhere('users',['place'=>'Right','parent'=>$id]);
		if($ru)
		{
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$this->downLineUserR($ru['user_id']);
			$right=$_SESSION['dList'];
			array_unshift($right, $ru['user_id']);
		}
		$arr['right']=$right;
		
	 	$RG = end($right); 
			return $RG;
		
	
	}
	public function countDownL($param='')
	{
        $left=[]; 
		unset($_SESSION['dList']);
		$_SESSION['dList']=[];
		$id= $param;
		$lu=$this->dbm->getWhere('users',['place'=>'Left','parent'=>$id]);
		if($lu)
		{
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$this->downLineUserL($lu['user_id']);
			$left=$_SESSION['dList'];
			array_unshift($left, $lu['user_id']);
		}
		$arr['left']=$left;
		  $LG = end($left); 
			return $LG;
		
	
	}
		 public function RepurchageCommission($param1='')
    {
         $grandeLeftAMT=0; $extraLeft=0; $extraRight=0; $leftAmt=0; $rightAmt=0; $pairAmt = 0; $grandeLeft = 0; $granderight= 0; $currentPairMach = 0; $grandeLeftAMT = 0; $granderightAMT =0; $previousLeft =0; $previousRightAmt = 0;
        $right=[]; $left=[]; $down=[];
        unset($_SESSION['dList']);
        $_SESSION['dList']=[];
        $id=$param1;
        $leftUser = $this->db->get_where('users',['place'=>'Left','sponcer_id'=>$id,'status'=>1])->num_rows();
        if($leftUser>=1){
        $lu=$this->dbm->getWhere('users',['place'=>'Left','parent'=>$id]);
        if($lu)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($lu['user_id']);
            $left=$_SESSION['dList'];
            array_unshift($left, $lu['user_id']);
        }
        }
        $RightUser = $this->db->get_where('users',['place'=>'Right','sponcer_id'=>$id,'status'=>1])->num_rows();
        if($RightUser>=1){
        $ru=$this->dbm->getWhere('users',['place'=>'Right','parent'=>$id]);
        if($ru)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($ru['user_id']);
            $right=$_SESSION['dList'];
            array_unshift($right, $ru['user_id']);
        }
        }
        // $arr['down']=$down;
        $arr['left']=$left;
        $arr['right']=$right;    
          
        $check = $this->db->group_by('user_id')->select('*,sum(pairAmt) as total')->get_where('pairmaching',['user_id'=>$id])->row_array();
        if($check){
        	$previousLeft = $check['total'];
        	$previousRightAmt = $check['total'];
        
        }
        foreach ($arr['left'] as $key => $val)
        {
            $prp=$this->db->select('user_id,sum(place_id) as total')->get_where('users',['user_id'=>$val,'status'=>1])->row_array();
        
             $leftAmt = $prp['total'];
            $grandeLeftAMT  = $grandeLeftAMT+$leftAmt;
        }
           $grandeLeft  =  $grandeLeftAMT-$previousLeft;
        // echo "<pre>"; print_r($grandeLeft);    
        foreach ($arr['right'] as $key => $value)
        {
           $prp=$this->db->select('user_id,sum(place_id) as total')->get_where('users',['user_id'=>$value,'status'=>1])->row_array();
               $rightAmt = $prp['total'];
               $granderightAMT = $granderightAMT+$rightAmt;    
        }

       $repurchase = $this->db->get_where('product_plan')->row_array(); 
       // print_r($repurchase); die();
          $granderight = $granderightAMT-$previousRightAmt;
         if($grandeLeft>=$granderight)
         {
             $data['date']= date('Y-m-d');
             $data['user_id'] = $id;
             $data['pairAmt'] = $granderight;
             $bonus = ($granderight*$repurchase['repurchase_comm'])/100;
             $tdsAdm = ($bonus*0)/100;
             $data['paidAmt'] = $bonus-$tdsAdm;
             $data['extraAmtLeft'] = $grandeLeft-$granderight;
             $data['leftAmt'] = $grandeLeft;
             $data['rightAmt'] = $granderight;
             $data['type'] = "1:1";
             // $data['currentPairMach'] = $check['currentPairMach']+$granderight;
         }
         if($grandeLeft<=$granderight)
         {
             $data['date']= date('Y-m-d');
             $data['user_id'] = $id;
             $data['pairAmt'] = $grandeLeft;
             $bonus = ($grandeLeft*$repurchase['repurchase_comm'])/100;
             $tdsAdm = ($bonus*0)/100;
             $data['paidAmt'] = $bonus-$tdsAdm;
             $data['extraAmtRight'] = $granderight-$grandeLeft;
             $data['leftAmt'] = $grandeLeft;
             $data['rightAmt'] = $granderight;
             $data['type'] = "1:1";
              // $data['currentPairMach'] = $check['currentPairMach']+$grandeLeft;
         }
             // ...........tds with comm.......................
         if ($bonus>0) {
         	$deduction['tds']=($bonus*0)/100;
			$deduction['admin']=($bonus*0)/100;
			$deduction['user_id']=$id;
			$deduction['date']=date('Y-m-d');
			$deduction['time']=date('H:i:s');
			$deduction['amount']=$data['paidAmt'];
			$deduction['type']='REPURCHAGE';
			$left=($bonus-($deduction['admin']+$deduction['tds']));
            $this->db->insert('tds',$deduction);
            $usr=$this->dbm->getWhere('users',['user_id'=>$id]);
            $wall=$left+$usr['wallet'];
		    $this->dbm->globalUpdate('users',['user_id'=>$usr['user_id']],['wallet'=>$wall]);
            $this->db->insert('pairmaching',$data);  
         	
         }
	          

    }
    
     public function closeNow()
	{
	    $arr=$this->dbm->globalSelect('users',['status'=>1,'wallet>='=>20]);
	    foreach ($arr as $key => $value)
	    {
	    	$data['amount']=floor($value['wallet']);
	    	$data['payment_mode']='Bank';
			$data['account_number']=($value['account_number'])?$value['account_number']:'Not Added';
			$data['branch_name']=($value['branch_name'])?$value['branch_name']:'Not Added';
			$data['bank_name']=($value['bank_name'])?$value['bank_name']:'Not Added';
			$data['ifsc']=($value['ifsc'])?$value['ifsc']:'Not Added';
			$data['user_id']=$value['user_id'];
			$data['date']=date('Y-m-d');
			$data['time']=date('H:i:s');
			$data['status']=0;
			//echo "<pre>"; print_r($data);
			$res=$this->dbm->globalInsert('withdraw',$data);
			if($res)
			{
				$msg="Dear ".$value['user_id']." your payout for Rs.".$data['amount']." is released. The amount will reflect in your bank in next 4 days. Thanks and Regards. demo.com"; 
				$this->dbm->sendSms($value['mobile'],$msg);
			    $amt=($value['wallet']-$data['amount']);
				$this->dbm->globalUpdate('users',['user_id'=>$value['user_id']],['wallet'=>$amt]);
				// $this->setMessage('1','Request Send Successfully.');
			}
	    }
	   // echo "Request Successfully Placed";
	}

	public function Spon_incom()
	{
	  $result=$this->dbm->globalSelect('users',['access'=>"limited",'status'=>1,'product!='=>11]);
     	    foreach ($result as $key => $value) {
     	 	   $this->binaryCommission($value['user_id']);
      	   	}
	}

		 public function binaryCommission($param1='')
    {
         $grandeLeftAMT=0; $extraLeft=0; $extraRight=0; $leftAmt=0; $rightAmt=0; $pairAmt = 0; $grandeLeft = 0; $granderight= 0; $currentPairMach = 0; $grandeLeftAMT = 0; $granderightAMT =0; $previousLeft =0; $previousRightAmt = 0;
        $right=[]; $left=[]; $down=[];
        unset($_SESSION['dList']);
        $_SESSION['dList']=[];
        $id=$param1;
        // $leftUser = $this->db->get_where('users',['place'=>'Left','sponcer_id'=>$id,'status'=>1])->num_rows();
        // if($leftUser>=1){
        $lu=$this->dbm->getWhere('users',['place'=>'Left','parent'=>$id]);
        if($lu)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($lu['user_id']);
            $left=$_SESSION['dList'];
            array_unshift($left, $lu['user_id']);
        }
        // }
        // $RightUser = $this->db->get_where('users',['place'=>'Right','sponcer_id'=>$id,'status'=>1])->num_rows();
        // if($RightUser>=1){
        $ru=$this->dbm->getWhere('users',['place'=>'Right','parent'=>$id]);
        if($ru)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($ru['user_id']);
            $right=$_SESSION['dList'];
            array_unshift($right, $ru['user_id']);
        }
        // }
        // $arr['down']=$down;
        $arr['left']=$left;
        $arr['right']=$right;    
          
        $check = $this->db->group_by('user_id')->select('*,sum(pairAmt) as total')->get_where('sponcer_tracker',['user_id'=>$id])->row_array();
        if($check){
        	$previousLeft = $check['total'];
        	$previousRightAmt = $check['total'];
        
        }
        foreach ($arr['left'] as $key => $val)
        {
            $prp=$this->db->select('user_id,sum(topup) as total')->get_where('users',['user_id'=>$val,'status'=>1])->row_array();
        
             $leftAmt = $prp['total'];
            $grandeLeftAMT  = $grandeLeftAMT+$leftAmt;
        }
           $grandeLeft  =  $grandeLeftAMT-$previousLeft;
        // echo "<pre>"; print_r($grandeLeft);    
        foreach ($arr['right'] as $key => $value)
        {
           $prp=$this->db->select('user_id,sum(topup) as total')->get_where('users',['user_id'=>$value,'status'=>1])->row_array();
               $rightAmt = $prp['total'];
               $granderightAMT = $granderightAMT+$rightAmt;    
        }
          $granderight = $granderightAMT-$previousRightAmt;
         if($grandeLeft>=$granderight)
         {
             $data['date']= date('Y-m-d');
             $data['user_id'] = $id;
             $data['pairAmt'] = $granderight;
             $bonus = $granderight;
             $tdsAdm = ($bonus*0)/100;
             $data['paidAmt'] = $bonus-$tdsAdm;
         }
         if($grandeLeft<=$granderight)
         {
             $data['date']= date('Y-m-d');
             $data['user_id'] = $id;
             $data['pairAmt'] = $grandeLeft;
             $bonus = $grandeLeft;
             $tdsAdm = ($bonus*0)/100;
             $data['paidAmt'] = $bonus-$tdsAdm;
         }
            
         	if ($bonus>0) {

         		 $spon = $this->db->get_where('users',['user_id'=>$id])->row_array();
         		 $data['sponcer_id'] = $spon['sponcer_id'];
         		 $this->db->insert('sponcer_tracker',$data);
	             $this->levelbinary($data);
         	}
                

    }

	public function levelbinary($data='')
	{
		$data['amt']=$data['paidAmt'];
		$comm['user_id']=$data['user_id'];
		$comm['sponcer_id']=$data['sponcer_id'];
		$comm['date']=date('Y-m-d');
		$comm['type']='SPONCER_COMM';
		$level=$this->dbm->globalSelect('level',['type'=>'self']);
		foreach($level as $key => $value)
		{
			$res=$this->db->get_where('users',['user_id'=>$data['sponcer_id'],'access'=>'limited'])->row_array();
			if(!$res){ break; }
			if($res['pan']=='')
			{
				$tds=0;
			}else
			{
				$tds=0;
			}
			$data['amount'] = ($data['amt']*$value['bonus'])/100;
			$comm['beneficiary']=$res['user_id'];
			$deduction['tds']=($data['amount']*$tds)/100;
			$deduction['admin']=($data['amount']*0)/100;
			$deduction['user_id']=$res['user_id'];
			$deduction['date']=date('Y-m-d');
			$deduction['time']=date('H:i:s');
			$deduction['amount']=$data['amount'];
			$deduction['type']='SPONCER_COMM';
			$deduction['admin_percent']=0;
			$deduction['tds_percent']=$tds;
			$left=($data['amount']-($deduction['admin']+$deduction['tds']));
			if($res['status']==1)
			{
				$wall=$left+$res['wallet'];
				$this->dbm->globalUpdate('users',['user_id'=>$res['user_id']],['wallet'=>$wall]);
				$comm['status']=1;
				$deduction['status']=1;
				$comm['is_credit']=1;
				$deduction['is_credit']=1;
			}else
			{
				$comm['status']=0;
				$deduction['status']=0;
				$comm['is_credit']=0;
				$deduction['is_credit']=0;
			}
			$comm['amount']=(($data['amount'])-($deduction['admin']+$deduction['tds']));
			$comm['level']=$value['level'];
			$comm['time']=date('H:i:s');
			$trncId=$this->dbm->transactionNumber();
			$comm['transaction']='C'.$trncId;
			$deduction['transaction']=$comm['transaction'];
			//echo "<pre>"; print_r($comm);
			$this->db->insert('tds',$deduction);
			$this->db->insert('commission',$comm);
			$data['sponcer_id']=$res['sponcer_id'];
		}
	}
	
	public function pairCount($param1)
	{
	    $grandeLeftAMT=0; $extraLeft=0; $extraRight=0; $leftAmt=0; $rightAmt=0; $pairAmt = 0; $grandeLeft = 0; $granderight= 0; $currentPairMach = 0; $grandeLeftAMT = 0; $granderightAMT =0; $previousLeft =0; $previousRightAmt = 0;
        $right=[]; $left=[]; $down=[];
        unset($_SESSION['dList']);
        $_SESSION['dList']=[];
        $id=$param1;
        // $leftUser = $this->db->get_where('users',['place'=>'Left','sponcer_id'=>$id,'status'=>1])->num_rows();
        // if($leftUser>=1){
        $lu=$this->dbm->getWhere('users',['place'=>'Left','parent'=>$id]);
        if($lu)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($lu['user_id']);
            $left=$_SESSION['dList'];
            array_unshift($left, $lu['user_id']);
        }
        // }
        // $RightUser = $this->db->get_where('users',['place'=>'Right','sponcer_id'=>$id,'status'=>1])->num_rows();
        // if($RightUser>=1){
        $ru=$this->dbm->getWhere('users',['place'=>'Right','parent'=>$id]);
        if($ru)
        {
            unset($_SESSION['dList']);
            $_SESSION['dList']=[];
            $this->downLineUserMatch($ru['user_id']);
            $right=$_SESSION['dList'];
            array_unshift($right, $ru['user_id']);
        }
        // }
        // $arr['down']=$down;
        $arr['left']=count($left);
        $arr['right']=count($right);
        return $arr;
	    
	}
	

}