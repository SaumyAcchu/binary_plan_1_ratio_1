<?php
class Db_model extends CI_Model
{
	public function globalInsert($table='',$data='')
	{
		$query=$this->db->insert($table,$data);
		return $this->db->insert_id();
	}
	public function selectAll($table='')
	{
		$query=$this->db->select('*')->get($table)->result_array();
		return $query;
	}
	public function globalDelete($table='',$condition='')
	{
		$query=$this->db->where($condition)->delete($table);

		return $query;
	}
	public function globalDeleteImage($table='',$condition='',$logo='',$favicon='')
	{
		//$this->db->where($condition);
        
        unlink("uploads/".$logo);
        unlink("uploads/".$favicon);
       
        $query = $this->db->delete($table, $condition);
		return $query;
	}

	public function globalDeleteSlides($table='',$condition='',$slides_image='')
	{
		
		//$this->db->where($condition);
        
        unlink("uploads/slider/".$slides_image);
       
        $query = $this->db->delete($table, $condition);
		return $query;
	}

	public function DeletePageImages($table = '', $condition = '', $image = '')
	{
		unlink("uploads/".$image);
        //unlink("uploads/".$favicon);
       
        $query = $this->db->delete($table, $condition);
		return $query;
	}

	public function selectRow($table='',$condition='')
	{
		$query=$this->db->get_where($table,$condition)->row_array();
		
		return $query;	
	}

	public function globalUpdate($table='',$data='',$condition='')
	{
		$query=$this->db->where($condition)->update($table,$data);
		return $query;
	}

	public function login( $username, $password )
	{
		$q = $this->db->select('*')
						->where(['user_id'=>$username, 'password'=>$password])
						->get('users');

		if( $q->num_rows() )
		{
			return $q->result();
		}
		else
		{
			return FALSE;
		}
	}
}