<?php
class Commission_model extends CI_Model
{
	public function levelbinary($data='')
	{
		
		$data['user_id']= "OX975942";
		$data['sponcer_id']="OX758298";
		$data['amt']=500;
		$comm['user_id']=$data['user_id'];
		$comm['sponcer_id']=$data['sponcer_id'];
		$comm['date']=date('Y-m-d');
		$comm['type']='SPONCER_COMM';
		$level=$this->dbm->globalSelect('level',['type'=>'self']);
		foreach($level as $key => $value)
		{
			$res=$this->db->get_where('users',['user_id'=>$data['sponcer_id'],'access'=>'limited'])->row_array();
			if(!$res){ break; }
			if($res['pan']=='')
			{
				$tds=5;
			}else
			{
				$tds=5;
			}
			$data['amount'] = ($data['amt']*$value['bonus'])/100;
			$comm['beneficiary']=$res['user_id'];
			$deduction['tds']=($data['amount']*$tds)/100;
			$deduction['admin']=($data['amount']*10)/100;
			$deduction['user_id']=$res['user_id'];
			$deduction['date']=date('Y-m-d');
			$deduction['time']=date('H:i:s');
			$deduction['amount']=$data['amount'];
			$deduction['type']='SPONCER_COMM';
			$deduction['admin_percent']=5;
			$deduction['tds_percent']=$tds;
			$left=($data['amount']-($deduction['admin']+$deduction['tds']));
			if($res['status']==1)
			{
				$wall=$left+$res['wallet'];
				$this->dbm->globalUpdate('users',['user_id'=>$res['user_id']],['wallet'=>$wall]);
				$comm['status']=1;
				$deduction['status']=1;
				$comm['is_credit']=1;
				$deduction['is_credit']=1;
			}else
			{
				$comm['status']=0;
				$deduction['status']=0;
				$comm['is_credit']=0;
				$deduction['is_credit']=0;
			}
			$comm['amount']=(($data['amount'])-($deduction['admin']+$deduction['tds']));
			$comm['level']=$value['level'];
			$comm['time']=date('H:i:s');
			$trncId=$this->dbm->transactionNumber();
			$comm['transaction']='C'.$trncId;
			$deduction['transaction']=$comm['transaction'];
			//echo "<pre>"; print_r($comm);
			$this->db->insert('tds',$deduction);
			$this->db->insert('commission',$comm);
			$data['sponcer_id']=$res['sponcer_id'];
		}
	}
}
