<?php
class Reward extends CI_Model
{


	public function rewardstart($value='')
	{
		  $this->load->model('comm');
		   // echo $value.'<br>';
		   $data['user_id'] = $value;
			$reqStrongLeg =0; $reqWeakLeg =0; 
			$totaljoin = $this->countSelfPair($data['user_id']);
			$SponCount = $this->db->get_where('users',['sponcer_id'=>$data['user_id']])->num_rows();
			$rewards = $this->dbm->globalSelect('rewards');
			foreach ($rewards as $key => $rewardsLavel) 
			{	
				$row =$this->dbm->rowCount('reward_income',['user_id'=>$data['user_id'],'reward_level'=>$rewardsLavel['level']]);
				$t = 0;
				if ($row<1) 
				{
					if ($totaljoin>=$rewardsLavel['pair']&&$t==0&&$SponCount>=$rewardsLavel['direct']) 
					{
						  $selfDirect=$this->dbm->globalSelect('users',['sponcer_id'=>$data['user_id'],'status'=>1]);
							foreach ($selfDirect as $key => $value) 
							{
								$join = $this->countSelfPair($value['user_id']);
								$joinarry[$value['user_id']] = $join;					
							}
							$maxJoin = max($joinarry);
							$weakJoin = $totaljoin - $maxJoin;
							if ($maxJoin>=$reqStrongLeg && $weakJoin>=$reqWeakLeg ) {
								$maxJoinId = array_search($maxJoin, $joinarry);
								$rwdata['user_id'] = $data['user_id'];
								$rwdata['rqrd_team'] = $rewardsLavel['pair'];
								$rwdata['reward_level'] = $rewardsLavel['level'];
								$rwdata['reward_name'] = $rewardsLavel['name'];
								$rwdata['date']=date('Y-m-d');
								$rwdata['time']=date('H:i:s');
								$rwdata['club']='reward';
								$trncId=$this->dbm->transactionNumber();
								$rwdata['transaction']='RW'.$trncId;
								$rwdata['member'] = $totaljoin;
								$this->dbm->globalInsert('reward_income',$rwdata);
							}
					}
					else{

						$t = 1;
					}

				}
			}
		
	}


	public function countSelfPair($value='')
	{
	       $pairs = $this->comm->pairCount($value);
         		if($pairs['left'] >= $pairs['right']){
         		    $possiblePairs = $pairs['right'];
         		}else{
         		    $possiblePairs = $pairs['left'];
         		}
         		return $possiblePairs;
	}
	

}