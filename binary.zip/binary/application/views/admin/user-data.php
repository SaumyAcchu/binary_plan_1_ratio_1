<!DOCTYPE html>
<html>
<head>
	<title><?=$this->siteInfo['name'];?></title>
	<?php $this->load->view('includes/header.php'); ?>
</head>
<body class="home">
	<div class="container-fluid no-padding display-table">
		<div class="row no-padding display-table-row">
			<div class="col-lg-2 no-padding bx-shdw col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
				<?php $this->load->view('includes/sidebar.php',['page'=>'my-profile']); ?>
			</div>
			<div class="col-lg-10 col-md-10 col-sm-11 display-table-cell v-align">
				<?php $this->load->view('includes/topbar.php'); ?>
				<div class="container-fluid no-padding main-container">
					<div class="title txtcenter">
						<h4>My Profile</h4>
					</div>
					<!-- ///Flash Message Start/// -->
					<?php if($alert=$this->session->flashdata('msg')): $class=$this->session->flashdata('msg_class'); ?>
					  <div class="row"><div class="col-sm-6 col-sm-offset-3"><div class="alert alert-dismissible <?= $class; ?> txtblack"><button type="button" class="close" data-dismiss="alert">&times;</button><p><?php echo $alert; ?></p></div></div></div>
					  <?php endif; ?>
					<!-- ///Flash Message End/// -->
<!-- ///=====================All Contents Start Here==========================================/// -->
		<?php if($user==0) { echo "<h1 class='text-center'>Sorry, User ID Not Found.</h1>"; }else{ ?>
	    <div class="col-lg-12">
	    	<div class="well well-sm">
                <div class="row">
                  <div class="col-sm-6 col-md-2">
                    <img title="profile image" class="img-circle img-responsive profile-image" src="<?=base_url('uploads/'.$user['image']);?>">
                  </div>
                  <div class="col-sm-6 col-md-4">
                    <h4><i class="glyphicon glyphicon-user"></i> <strong><?=$user['name'];?></strong></h4>
                       <i class="fa fa-vcard-o"> User ID</i> :  <?=$user['user_id'];?><br><i class="fa fa-shopping-cart"> Product</i> :  <?=$user['product'];?><br><br>
                        <!-- Split button -->
                        <!-- <a href="<?=base_url('user/getData/'.base64_encode('users/'.$user['id'].'/update-profile'));?>" class="btn btn-success"> Update Profile</a> -->
                    </div>
                    <div class="col-sm-6 col-md-3"><br>
                    	<div class="panel panel-primary">
	                        <div class="panel-heading">
		                        <div class="row">
		                        	<div class="col-xs-4">
		                            	<i class="fa fa-inr fa-5x"></i>
		                          	</div>
		                          	<div class="col-xs-8 text-right">
		                            	<p class="announcement-heading">Wallet Balanace</p>
		                            	<h3 class="announcement-text"><?=number_format($user['wallet'],2);?></h3>
		                          	</div>
		                        </div>
	                        </div>
	                    </div>
                    </div>
                    <div class="col-sm-6 col-md-3"><br>
                    	<div class="panel panel-primary">
	                        <div class="panel-heading">
		                        <div class="row">
		                        	<div class="col-xs-4">
		                            	<i class="fa fa-inr fa-5x"></i>
		                          	</div>
		                          	<div class="col-xs-8 text-right">
		                            	<p class="announcement-heading">Topup Balanace</p>
		                            	<h3 class="announcement-text"><?=number_format($user['topup'],2);?></h3>
		                          	</div>
		                        </div>
	                        </div>
	                    </div>
                    </div>
                </div>
            </div>
		</div>
	    <br>
	    <div class="row">
	        <div class="col-sm-3">
	            <!--left col-->
	            <ul class="list-group">
	                <li class="list-group-item active text-muted" contenteditable="false">Profile</li>
	                <li class="list-group-item text-right"><span class="pull-left"><strong class="">Sponcer ID</strong></span> <?=$user['sponcer_id'];?></li>
	                <li class="list-group-item text-right"><span class="pull-left"><strong class="">Password</strong></span> <?=$user['password'];?></li>
	                <li class="list-group-item text-right"><span class="pull-left"><strong class="">Joined</strong></span> <?=$this->db_model->dateFormat($user['reg_date']);?></li>
	                <li class="list-group-item text-right"><span class="pull-left"><strong class="">Mobile</strong></span> <?=$user['mobile'];?></li>
	            </ul>
	           <div class="panel panel-default">
	            	<div class="panel-heading">
	            		Account Status
	                </div>
	                <div class="panel-body">
	                	<?=($user['status']==1)?'<i style="color:green" class="fa fa-check-square"></i> Yes, Account is Active.':'<i style="color:red" class="fa fa-ban"></i> No, Account is Not Active.';?>
	                </div>
	            </div>
	        </div>
	        <!--/col-3-->
	        <div class="col-sm-9" style="" contenteditable="false">
	            <div class="panel panel-info">
	                <div class="panel-heading">
	                	Account Details
	                </div>
	                <div class="panel-body">
	                <table class="table table-bordered table-striped table-hover">
	                	<tr>
	                		<th>Activation PIN</th><td><?=$user['pin'];?></td>
	                		<th>Activate Date</th><td><?=$this->db_model->dateFormat($user['active_date']);?> <?=$user['active_time'];?></td>
	                	</tr>
	                	<tr>
	                		<th>Paytm Account Number</th><td colspan="3"><?=($user['paytm'])?$user['paytm']:'Not Added Yet';?></td>
	                	</tr>
	                	<tr>
	                		<th>Bank Account Number</th>
	                		<td><?=($user['account_number'])?$user['account_number']:'Not Added Yet';?></td>
	                		<th>Bank Name</th>
	                		<td><?=($user['bank_name'])?$user['bank_name']:'Not Added Yet';?></td>
	                	</tr>
	                	<tr>
	                		<th>IFSC Code</th>
	                		<td><?=($user['ifsc'])?$user['ifsc']:'Not Added Yet';?></td>
	                		<th>Branch Name</th>
	                		<td><?=($user['branch_name'])?$user['branch_name']:'Not Added Yet';?></td>
	                	</tr>
	                	<tr>
	                		<th>Email ID</th><td colspan="3"><?=($user['email'])?$user['email']:'Not Added Yet';?></td>
	                	</tr>
	                	<tr>
	                		<th>Permanent Address</th><td colspan="3"><?=($user['address'])?$user['address']:'Not Added Yet';?></td>
	                	</tr>
	                </table>
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="row">
		    <div class="col-lg-6">
		    	<div class="panel panel-primary">
	                <div class="panel-heading">
	                    <h3 class="panel-title"><i class="fa fa-line-chart"></i> Universal Club Upgradation </h3>
	                </div>
	                <div class="panel-body">
	                    <ul class="list-group">
	                    	<?php $upgAmt=0; $i=1; $list=$this->db_model->globalSelect('plans');
	                    	foreach ($list as $key => $upgd) {
	                    	$check=$this->db_model->rowCount('upgrade',['plan_id'=>$upgd['id'],'user_id'=>$user['user_id']]);
	                    	if($check>0) {
	                    	$upgAmt=$upgAmt+$upgd['join_amt']; ?>
			                <li class="list-group-item text-right list-group-item-success"><span class="pull-left"><strong class=""> <?=$i;?>. <?=$upgd['name'];?></strong></span> <i class="fa fa-check-circle"></i></li>
			                <?php }else{ ?>
			                <li class="list-group-item text-right list-group-item-danger"><span class="pull-left"><strong class=""><?=$i;?>. <?=$upgd['name'];?></strong></span>  <i class="fa fa-times-circle"></i></li>
			                <?php } ?>
			                <?php $i++; } ?>
			            </ul>
	                </div>
	            </div>
		    </div>
		    <div class="col-lg-6">
		    	<div class="panel panel-primary">
	                <div class="panel-heading">
	                    <h3 class="panel-title"><i class="fa fa-cogs"></i> Expense Amount</h3>
	                </div>
	                <div class="panel-body">
	                    <div class="row">
	                        <div class="col-xs-6 b2">
						        <div class="label-primary" style="padding: 5px; border-radius: 6px;">
						            <button class="btn btn-info btn-lg btn-block" role="button" style="padding: 2px;">
						                <div class="fa fa-pinterest-p fa-3x"></div>
						                <div class="icon-label">Self PIN Generate</div>
						            </button> 
						            <button class="btn btn-default btn-block" style="height: 40px;">
						                <span class="badge"> <?=$pinCount;?> </span>
						            </button>
						        </div>
						    </div>
						    <div class="col-xs-6 b2">
						        <div class="label-primary" style="padding: 5px; border-radius: 6px;">
						            <button class="btn btn-info btn-lg btn-block" role="button" style="padding: 2px;">
						                <div class="fa fa-money fa-3x"></div>
						                <div class="icon-label">Withdrawal</div>
						            </button> 
						            <button class="btn btn-default btn-block" style="height: 40px;">
						                <span class="badge"> <i class="fa fa-inr"></i> <?=number_format($withdraw,2);?> </span>
						            </button>
						        </div>
						    </div>
					    	<table class="table" style="margin-bottom: 0px;">
					    		<tr>
					    			<td>PIN Generate</td><td class="min">: <?=number_format($pin=$pinCount*365,2);?></td>
					    			<td>Withdraw</td><td class="min">: <?=number_format($withdraw,2);?></td>
					    		</tr>
					    		<tr>
					    			<td>Account Upgrade</td><td>: <?=number_format($upgAmt,2);?></td>
					    			<th class="bg-success">Total</th><td class="bg-success">: <?=number_format($withdraw+$upgAmt+$pin,2);?></td>
					    		</tr>
					    	</table>
	                    </div>
	                </div>
	            </div>
		    </div>
		</div>
		<div class="panel panel-primary">
	    <div class="panel-heading">
	      <h3 class="panel-title">Total Income Till Now | <span class="badge">Total :  <i class="fa fa-inr"></i> <?=number_format($total,2);?></span></h3>
	    </div>
	    <div class="panel-body">
	    <div class="col-lg-2 col-xs-6 b2">
	        <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-info btn-lg btn-block" role="button" style="padding: 2px;">
	                <div class="fa fa-sitemap fa-3x"></div>
	                <div class="icon-label">Self Team</div>
	            </button> 
	            <button class="btn btn-default btn-block" style="height: 40px;">
	                <span class="badge"> <i class="fa fa-inr"></i> <?=number_format($self_amt,2);?> </span>
	            </button>
	        </div>
	    </div>
	    
	      <div class="col-lg-2 col-xs-6 b2">
	          <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-warning btn-lg btn-block" role="button" style="padding: 2px;">
	            <div class="fa fa-adn fa-3x"></div>
	            <div class="icon-label">
	             India A
	            </div></button> <button class="btn btn-default btn-block" style="height: 40px;">
	            	<span class="badge"><i class="fa fa-inr"></i>  <?=number_format($indiaA_amt,2);?> </span>
	            </button>
	          </div>
	        </div>
	    
	        <div class="col-lg-2 col-xs-6 b2">
	          <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-warning btn-lg btn-block" role="button" style="padding: 2px;">
	            <div class="fa fa-btc fa-3x"></div>
	            <div class="icon-label">
	              India B
	            </div></button> <button class="btn btn-default btn-block" style="height: 40px;">
	            	<span class="badge"><i class="fa fa-inr"></i>  <?=number_format($indiaB_amt,2);?> </span>
	            </button>
	          </div>
	        </div>
	        
	        <div class="col-lg-2 col-xs-6 b2">
	          <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-success btn-lg btn-block" role="button" style="padding: 2px;">
	            <div class="fa fa-universal-access fa-3x"></div>
	            <div class="icon-label">
	             Universal Club
	            </div></button> <button class="btn btn-default btn-block" style="height: 40px;">
	            	<span class="badge"><i class="fa fa-inr"></i>  <?=number_format($universal_amt,2);?> </span>
	            </button>
	          </div>
	        </div>
	        
	        <div class="col-lg-2 col-xs-6 b2">
	          <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-danger btn-lg btn-block" role="button" style="padding: 2px;">
	            <div class="fa fa-suitcase fa-3x"></div>
	            <div class="icon-label">
	             Royalty
	            </div></button> <button class="btn btn-default btn-block" style="height: 40px;">
	            	<span class="badge"><i class="fa fa-inr"></i>  <?=number_format($royalty_amt,2);?> </span>
	            </button>
	          </div>
	        </div>
	        
	        <div class="col-lg-2 col-xs-6 b2">
	          <div class="label-primary" style="padding: 5px; border-radius: 6px;">
	            <button class="btn btn-primary btn-lg btn-block" role="button" style="padding: 2px;">
	            <div class="fa fa-line-chart fa-3x"></div>
	            <div class="icon-label">
	             Leader Club
	            </div></button> <button class="btn btn-default btn-block" style="height: 40px;">
	            	<span class="badge"><i class="fa fa-inr"></i>  <?=number_format($leader_amt,2);?> </span>
	            </button>
	          </div>
	        </div>
	        <hr>
	        <center><a href="<?=base_url('control/paymentHistory/'.$user['user_id']);?>" class="btn btn-primary"><i class="fa fa-history"></i> All Payment History</a></center>
		</div>
	</div>
	<div class="panel panel-primary">
		<div class="panel-heading">
		    <h3 class="panel-title"><i class="fa fa-sitemap"></i> Direct Joins <span class="badge"><?=count($directs); ?></span></h3>
		</div>
		<div class="panel-body">
			<?php foreach ($directs as $key => $down) { ?>
		    <div class="col-lg-3 col-xs-6 b2">
                <div class="well text-center dwell">
                	<div class="dirImg">
		            	<center><img src="<?=base_url('uploads/'.$down['image']);?>" width="50" height="50" alt="<?=$down['name'];?>" class="img-circle" /></center>
		        	</div>
		        	<p><?=$down['user_id']; ?></p>
		            <a href="<?=base_url('control/userData/'.$down['user_id']);?>" class="btn btn-success btn-block"><?=$down['name'];?></a>
		        </div>
		    </div>
		    <?php } ?>
		</div>
	</div>
	<div class="row">
	           			<div class="col-sm-4">
		                    <div class="panel panel-info">
		                        <div class="panel-heading">
			                        <div class="row">
			                        	<div class="col-xs-4">
			                            	<i class="fa fa-users fa-5x"></i>
			                          	</div>
			                          	<div class="col-xs-8 text-right">
			                            	<h3 class="announcement-text">Direct Joins</h3>
			                            	<?php $count=$this->db_model->rowCount('users',['sponcer_id'=>$user['user_id']]); ?>
			                            	<p class="announcement-heading"><?=$count;?></p>
			                          	</div>
			                        </div>
		                        </div>
		                        <a href="<?=base_url('control/statics/'.base64_encode('directAll/1/Direct Joins').'/'.$user['user_id']);?>">
			                        <div class="panel-footer announcement-bottom">
			                          	<div class="row">
			                            	<div class="col-xs-6">
			                              		Expand
			                            	</div>
			                            	<div class="col-xs-6 text-right">
			                              		<i class="fa fa-arrow-circle-right"></i>
			                            	</div>
			                          	</div>
			                        </div>
		                        </a>
		                    </div>
		                </div>


   <?php
		$activeSelf=[];
		$allSelf=[];
    	$self=$this->commission_model->selfTeam($user['user_id']);
    	if($self)
    	{
        	for ($s=1; $s <=12 ; $s++)
        	{
        		if(count($self[$s])>0)
        		{
	        		foreach ($self[$s] as $key => $down)
	        		{
	        			foreach ($down as $key => $val)
			    	 	{
			    	 		$allSelf[]=$val;
		        	 		if($val['status']==1)
		        	 		{
		        	 			$activeSelf[]=$val;
		        	 		}
			    	 	}
	        		}
	        	}
        	}
        }
			?>	
		                <div class="col-sm-4">
		                    <div class="panel panel-danger">
		                        <div class="panel-heading">
			                        <div class="row">
			                        	<div class="col-xs-4">
			                            	<i class="fa fa-sort-amount-asc fa-5x"></i>
			                          	</div>
			                          	<div class="col-xs-8 text-right">
			                            	<h3 class="announcement-text">Self Team</h3>
			                            	<p class="announcement-heading"><?=count($allSelf);?></p>
			                          	</div>
			                        </div>
		                        </div>
		                        <a href="<?=base_url('control/statics/'.base64_encode('selfAll/1/Self Team').'/'.$user['user_id']);?>">
			                        <div class="panel-footer announcement-bottom">
			                          	<div class="row">
			                            	<div class="col-xs-6">
			                              		Expand
			                            	</div>
			                            	<div class="col-xs-6 text-right">
			                              		<i class="fa fa-arrow-circle-right"></i>
			                            	</div>
			                          	</div>
			                        </div>
		                        </a>
		                    </div>
		                </div>

		                <div class="col-sm-4">
		                    <div class="panel panel-warning">
		                        <div class="panel-heading">
			                        <div class="row">
			                        	<div class="col-xs-4">
			                            	<i class="fa fa-line-chart fa-5x"></i>
			                          	</div>
			                          	<div class="col-xs-8 text-right">
			                            	<h3 class="announcement-text">All India</h3>
			                            	<p class="announcement-heading">Live Chart</p>
			                          	</div>
			                        </div>
		                        </div>
		                        <a href="<?=base_url('control/allIndiaLiveChart/'.$user['user_id']);?>">
			                        <div class="panel-footer announcement-bottom">
			                          	<div class="row">
			                            	<div class="col-xs-6">
			                              		Expand
			                            	</div>
			                            	<div class="col-xs-6 text-right">
			                              		<i class="fa fa-arrow-circle-right"></i>
			                            	</div>
			                          	</div>
			                        </div>
		                        </a>
		                    </div>
		                </div>
		            </div>
        <?php } ?>
<!-- ///=====================All Contents End Here============================================/// -->
				</div>
				<?php $this->load->view('includes/footer.php'); ?>
			</div>
		</div>
	</div>
</body>
</html>
<style type="text/css">
	.profile-image{
  height: 140px;
  width: 140px;
}
.min{
	min-width: 60px;
}
.badge{
	font-size: 17px;
}
.b2{
	padding-bottom: 15px;
}
.dirImg{
	height: 60px;
	padding-bottom: 10px;
}
.mq-friends{
    width:31.3%;
    height:100px;
    padding:0;
    position:relative;
    display:table;
    float:left;
    margin:0px 10px 10px 0px;
}

.mq-friends:hover{
    transition:.6s;
    transform:scale(.9);
}

.mq-friend-img{
    padding-top:10px;
}

.mq-friends-footer{
    width:100%;
    background-color:#3399ff;
    position:absolute;
    bottom:0;
    text-align:center;
    color:#fff;
}
.dwell{
	min-height: 165px;
}
</style>