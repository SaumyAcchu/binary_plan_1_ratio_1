<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?=$page['page']='Payout Report';?> | <?=$this->siteInfo['name'];?></title>
  	<?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
    	<?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
  	<div class="wrapper" id="wrapper">
    	<div class="left-container" id="left-container">
      	<!--========== Sidebar Start =============-->
      		<?php $this->load->view('include/sidebar',$page); ?>
      	<!--========== Sidebar End ===============-->
    	</div>
	    <div class="right-container" id="right-container">
	      	<div class="container-fluid">
		        <?php $this->load->view('include/page-top',$page); ?>
		        <!--//===============Main Container Start=============//-->
		        <div class="row padding-top">
		        	<div class="col-lg-10 col-lg-offset-1">
				    <?= form_open('auth/payoutReport',['class'=>'form-horizontal']); ?>
					<table class="table table-striped table-hover table-bordered">
					    <tr>
					      <td>
					        <div class="input-group" id="datepairExample">
					           <span class="input-group-addon" id="basic-addon1">From</span>
					           <input type="text" value="<?=set_value('dateFrom');?>" name="dateFrom" class="form-control date" id="datepicker" placeholder="dd-mm-yyyy" required>
					           <span class="input-group-addon" id="basic-addon2"><i class="fa fa-calendar"></i></span>
					        </div>
					      </td>
					      <td>
					      	<div class="input-group" id="datepairExample">
					           <span class="input-group-addon" id="basic-addon1">To</span>
					           <input type="text" value="<?=set_value('dateTo');?>" name="dateTo" class="form-control date" id="datepicker" placeholder="dd-mm-yyyy" required>
					           <span class="input-group-addon" id="basic-addon2"><i class="fa fa-calendar"></i></span>
					        </div>
					      </td>
					      <td style="padding-top: 12px;">
					     	<button type="submit" class="btn btn-danger btn-sm"> Get Report</button>
					      </td>
					    </tr>
					</table>
					</form>
			  	</div>
            <?php $ref=0; $bonus=0; $ind=0; $pair=0; $dir=0; $diru = 0; $auto=0; $fundd = 0;?>
			  
              <div class="col-lg-12">
		          <div class="panel panel-info" id="myPanel">
            <div class="panel-heading">
              <span class="panel-title">Payment History</span>
            </div>
          
            <div class="panel-body">
              <hr>
               <?php if(isset($referral)){ ?>
              <h4 class="txtblue">Sponcer Income</h4>
              <table id="table5" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr>
                    <th>Sl No.</th>
                    <th>TRXN</th>
                    <th>Beneficiary ID</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Level</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($referral as $key => $value) { ?>
                      <tr>
                        <td><?=$i;?></td>
                        <td><?=$value['transaction'];?></td>
                         <td><?=$value['beneficiary'];?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?>  <?=$value['time'];?></td>
                        <td><?=$value['level'];?></td>
                        <td><?=$value['amount'];
                        $dir=$dir+$value['amount']; ?></td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
                <?php } ?>
                <hr>
                <?php if(isset($india)){ ?>
              <h4 class="txtblue">Autopool Income</h4>
              <table id="table6" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr>
                    <th>Sl No.</th>
                    <th>TRXN</th>
                    <th>Level</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($india as $key => $value) { ?>
                      <tr>
                        <td><?=$i;?></td>
                        <td><?=$value['transaction'];?></td>
                         <td><?=$value['level'];?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?>  <?=$value['time'];?></td>
                        <td><?=$value['amount'];
                        $auto=$auto+$value['amount']; ?></td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
                <?php } ?>
                <hr>
                	<?php if(isset($pairMatch)){ ?>
                 <h4 class="txtblue">Pair Matching Income</h4>
              <table id="table2" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr>
                    <th>Sl No.</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($pairMatch as $key => $value) { ?>
                      <tr>
                        <td><?=$i;?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?>  </td>
                        <td><?=$value['amount'];
                        $bonus=$bonus+$value['amount']; ?></td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
              <?php } ?>
               <hr>
                <?php if(isset($upgrade)){ ?>
              <h4 class="txtblue">Repurchase Income</h4>
              <div style="overflow-x:auto;">
              <table id="table7" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr class="info">
                    <th>Sl No.</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($upgrade as $key => $value) { ?>
                      <tr class="warning">
                        <td><?=$i;?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?>  </td>
                        <td><?=$value['paidAmt'];
                        $diru=$diru+$value['paidAmt']; ?></td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
              </div>
                <?php } ?>
                <hr>
                <?php if(isset($rewards)){ ?>
              <h4 class="txtblue">Rewards Achievers</h4>
              <div style="overflow-x:auto;">
              <table id="table8" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr class="info">
                    <th>Sl No.</th>
                    <th>Rewards Level</th>
                    <th>Rewards Name</th>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($rewards as $key => $value) { ?>
                      <tr class="warning">
                        <td><?=$i;?></td>
                        <td><?=$value['reward_level'];?></td>
                        <td><?=$value['reward_name'];?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?>  <?=$value['time'];?></td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
              </div>
                <?php } ?>
                 <hr>
                <?php if(isset($fund)){ ?>
              <h4 class="txtblue">Fund Achievers</h4>
              <div style="overflow-x:auto;">
              <table id="table9" class="table table-condensed table-bordered table-striped table-hover">
                <thead>
                  <tr class="info">
                    <th>Sl No.</th>
                    <th> Level</th>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Amount</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                <?php $i=1; 
                foreach ($fund as $key => $value) { ?>
                      <tr class="warning">
                        <td><?=$i;?></td>
                        <td><?=$value['level'];?></td>
                        <td><?=$value['user_id'];?></td>
                        <td><?=$this->dbm->getName($value['user_id']);?></td>
                        <td><?=$value['amount'];
                        $fundd = $fundd+$value['amount'];
                        ?></td>
                        <td><?=$this->dbm->dateFormat($value['date']);?> </td>
                      </tr>
                <?php $i++; } ?>
                </tbody>
              </table>
              </div>
                <?php } ?>
            <div class="col-md-6 col-md-offset-3 well">
              <table class="table table-condensed table-hover table-bordered table-striped">
                <tr>
                  <td colspan="2"><h4 class="txtred"> Payment Summary</h4></td>
                </tr>
                <tr>
                  <td>Sponcer Income</td><td class="txtright"><?=$dir;?></td>
                </tr>
                <tr>
                  <td>Autopool Income</td><td class="txtright"><?=$auto;?></td>
                </tr>
                <tr>
                  <td>Pair Matching Income</td><td class="txtright"><?=$bonus;?></td>
                </tr>
                 <tr>
                  <td>Fund Income</td><td class="txtright"><?=$fundd;?></td>
                </tr>
                 
                <tr>
                  <td>Repurchase Income</td><td class="txtright"><?=$diru;?></td>
                </tr>
                <tr style="background: lavender;">
                  <th>Total</th><th class="txtright"><?=number_format($to=$bonus+$dir+$diru+$auto+$fundd,2); ?></th>
                </tr>
                <tr>
                  <th class="text-left" colspan="2">In Words: <?=$this->dbm->wordAmt($to);?></th>
                </tr>
              </table>
            </div>
          </div>
        </div>
        
		    </div>
	        <!--//===============Main Container End=============//-->
	      	</div>
	    </div>
  	</div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>
<script type="text/javascript">
  $(document).ready(function() {
  $('#table1').DataTable();
  });
  $(document).ready(function() {
  $('#table2').DataTable();
  });
  $(document).ready(function() {
  $('#table3').DataTable();
  });
  $(document).ready(function() {
  $('#table4').DataTable();
  });
  $(document).ready(function() {
  $('#table5').DataTable();
  });
  $(document).ready(function() {
  $('#table6').DataTable();
  });
  $(document).ready(function() {
  $('#table7').DataTable();
  });
  $(document).ready(function() {
  $('#table8').DataTable();
  });
   $(document).ready(function() {
  $('#table9').DataTable();
  });
    $('#datepairExample .date').datepicker({
                    'format': 'yyyy-mm-dd',
                    'autoclose': true
                });
</script>
<style type="text/css">
  .txtSize{
    font-size: 16px;
  }
  th{
    text-align: center;
  }
  td{
    text-align: center;
  }
  table{
    font-size: 14px;
  }
</style>