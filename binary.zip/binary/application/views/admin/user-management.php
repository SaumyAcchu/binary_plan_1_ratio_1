<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?=$page['page']='User Management';?> | <?=$this->siteInfo['name'];?></title>
  	<?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
    	<?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
  	<div class="wrapper" id="wrapper">
    	<div class="left-container" id="left-container">
      	<!--========== Sidebar Start =============-->
      		<?php $this->load->view('include/sidebar',$page); ?>
      	<!--========== Sidebar End ===============-->
    	</div>
	    <div class="right-container" id="right-container">
	      	<div class="container-fluid">
		        <?php $this->load->view('include/page-top',$page); ?>
		        <!--//===============Main Container Start=============//-->
		        <div class="row padding-top">
		            <div class="col-lg-12">
						<div class="panel panel-primary" id="myPanel">
							<div class="panel-heading">
								<p class="panel-title"><i class="fa fa-list"></i> Users List</p>
							</div>
							<div class="panel-body">
								<table id="table1" class="table table-condensed table-hover table-bordered">
									<thead>
										<tr>
											<th>Sl.</th>
											<th>User ID</th>
											<th>Password</th>
											<th>Name</th>
											<th>Sponcer ID</th>
											<th>DOJ</th>
											<th>Mobile</th>
											<th>Wallet</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									  <?php if($data) { $i=1;
									  	foreach ($data as $key => $value)
									  	{
									  		if($value['access']!='universal') { ?>
									  		<tr class="<?=($value['status']==1)?"bg-success":"bg-danger";?>">
									  			<td><?=$i;?></td>
									  			<td><?=$value['user_id'];?></td>
									  			<td><?=$value['password'];?></td>
									  			<td><?=$value['name'];?></td>
									  			<td><?=$value['sponcer_id'];?></td>
									  			<td><?=$this->dbm->dateFormat($value['reg_date']);?> <?=$value['reg_time'];?></td>
									  			<td><?=$value['mobile'];?></td>
									  			<td><?=$value['wallet'];?></td>
									  			<td>
									  				<div class="btn-group">
									  				
													<a class="btn btn-xs btn-info" href="<?=base_url('auth/getData/users/'.$value['id'].'/update-user');?>"> <i class="fa fa-pencil"></i> </a>
													<!--<a onclick="return condelUser()" class="btn btn-xs btn-danger" href="<?=base_url('auth/deleteData/users/'.$value['id'].'/user-management');?>"> <i class="fa fa-trash"></i> </a>-->
													<?php if($value['block']==1)
													{ ?>
														<a href="<?=base_url('auth/userBlock/'.$value['user_id'].'/unblock');?>" onclick="return unblock()" class="btn btn-xs btn-warning">Blocked</a> <?php
													}else
													{ ?>
														<a href="<?=base_url('auth/userBlock/'.$value['user_id'].'/block');?>" onclick="return block()" class="btn btn-xs btn-primary">Block</a>
													<?php } ?>
													</div>
									  			</td>
									  		</tr>
									  	<?php $i++; } } } else { ?>
										<tr><td colspan="7">No Records Found.</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>         
		        </div>
	        <!--//===============Main Container End=============//-->
	      	</div>
	    </div>
  	</div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>

<script type="text/javascript">
function sendPin(req_id,user_id)
{
	$('#req_id').val(req_id);
	$('#user_id').val(user_id);
}
$(document).ready(function() {
$('#table1').DataTable();
} );
$(document).ready(function() {
$('#table2').DataTable();
} );

	$('#pinGen').click(function(){
		$.ajax({
			url:"<?=base_url('auth/pinGenerate');?>",
			
			success:function(data)
			{
				$('#pin').val(data);
			}
		});
	});



	function condelUser()
	{
		var cnf =confirm('Are you Sure to Delete this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function block()
	{
		var cnf =confirm('Are you Sure to Block this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function unblock()
	{
		var cnf =confirm('Are you Sure to Unblock this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function walletChange(user,cash,topup)
	{
		$('#userId').val(user);
		$('#cashWallet').val(cash);
		$('#topupWallet').val(topup);
		$('#walletModal').modal('show');
	}
</script>
<style type="text/css">
	.btn-circle{
		border-radius: 50%;
	}
	.Udeactive{
		background: darkred;
		color: #fff;
	}
	.Uactive{
		background: darkgreen;
		color: #fff;
	}
</style>