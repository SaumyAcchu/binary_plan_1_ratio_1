<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?=$page['page']='Self Pay';?> | <?=$this->siteInfo['name'];?></title>
  	<?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
    	<?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
  	<div class="wrapper" id="wrapper">
    	<div class="left-container" id="left-container">
      	<!--========== Sidebar Start =============-->
      		<?php $this->load->view('include/sidebar',$page); ?>
      	<!--========== Sidebar End ===============-->
    	</div>
	    <div class="right-container" id="right-container">
	      	<div class="container-fluid">
		        <?php $this->load->view('include/page-top',$page); ?>
		        <!--//===============Main Container Start=============//-->
		        <div class="row padding-top">
		            <div class="col-lg-12">
						<div class="panel panel-primary" id="myPanel">
							<div class="panel-heading">
								<p class="panel-title"><i class="fa fa-list"></i> Payment List</p>
							</div>
							<?php
							$data=$this->dbm->globalSelect('users',['access'=>'limited','wallet>'=>99]); ?>
							<div class="panel-body">
								<table id="table1" class="table table-condensed table-hover table-bordered">
									<thead>
										<tr>
											<th>Sl.</th>
											<th>User ID</th>
											<th>Name</th>
											<th>Sponcer ID</th>
											<th>DOJ</th>
											<th>Mobile</th>
											<th>Wallet</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
									  <?php if($data) { $i=1;
									  	foreach ($data as $key => $value)
									  	{
									  		if($value['access']!='universal') { ?>
									  		<tr>
									  			<td><?=$i;?></td>
									  			<td><?=$value['user_id'];?></td>
									  			<td><?=$value['name'];?></td>
									  			<td><?=$value['sponcer_id'];?></td>
									  			<td><?=$this->dbm->dateFormat($value['reg_date']);?> <?=$value['reg_time'];?></td>
									  			<td><?=$value['mobile'];?></td>
									  			<td><?=$value['wallet'];?></td>
									  			<td>
													<a onclick="return payAmt('<?=$value['user_id'];?>','<?=$value['name'];?>','<?=$value['wallet'];?>','<?=$value['account_number'];?>','<?=$value['bank_name'];?>','<?=$value['ifsc'];?>','<?=$value['branch_name'];?>');" class="btn btn-xs btn-info" href="javascript:void(0);"> <i class="fa fa-send"></i> Pay</a>
									  			</td>
									  		</tr>
									  	<?php $i++; } } } else { ?>
										<tr><td colspan="8">No Records Found.</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>         
		        </div>
	        <!--//===============Main Container End=============//-->
	      	</div>
	    </div>
  	</div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>

<!-- Bootstrap Modal for Notice -->
  <div class="modal fade" id="payModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
      	<div class="modal-header">
      		<button class="close" data-dismiss="modal">&times;</button>
      		<p class="modal-title">User Payment</p>
      	</div>
        <div class="modal-body">
            <?=form_open('auth/selfPay'); ?>
            	<table class="table">
            		<tr>
            			<td colspan="2" class="text-center txtred">Available Amount : <b id="avl"></b></td>
            		</tr>
            		<tr id="bank1">
            		</tr>
            		<tr id="bank2">
            			
            		</tr>
            		<tr>
            			<th>User ID</th>
            			<td><input type="text" name="user_id" id="uid" class="form-control" readonly=""></td>
            		</tr>
            		<tr>
            			<th>Name</th>
            			<td><input type="text" name="" id="name" readonly="" class="form-control"></td>
            		</tr>
            		<tr>
            			<th>Pay Mode</th>
            			<td><select class="form-control" name="payment_mode" required="">
            				<option value="">Select Mode</option>
            				<option value="Cash">Cash</option>
            				<option value="Paytm">Paytm</option>
            				<option value="Bank">Bank</option>
            			</select></td>
            		</tr>
            		<tr>
            			<th>Amount</th>
            			<td><input placeholder="Enter Payment Amount" type="number" name="amount" id="amt" class="form-control"></td>
            		</tr>
            		<tr>
            			<th>Transaction No</th>
            			<td><input type="text" placeholder="Transaction number" name="trnx_num" id="" class="form-control"></td>
            		</tr>
            	</table>
        </div>
        <div class="modal-footer">
        	<button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure to Pay');"> <i class="fa fa-send"></i> Pay </button>
        </div>
        </form>
      </div>
    </div>
  </div>

        <!-- Modal End -->

<script type="text/javascript">

function payAmt(uid,name,amt,ac,bank,ifsc,branch)
{
	$('#uid').val(uid);
	$('#bank1').html('<td><b>Bank : </b>'+bank+'</td><td><b>A/C No. : </b>'+ac+'</td>');
	$('#bank2').html('<td><b>IFSC : </b>'+ifsc+'</td><td><b>Branch : </b>'+branch+'</td>');
	$('#name').val(name);
	$('#avl').html(amt);
	$('#amt').attr('max',amt);
	$('#payModal').modal('show');
}

function sendPin(req_id,user_id)
{
	$('#req_id').val(req_id);
	$('#user_id').val(user_id);
}
$(document).ready(function() {
$('#table1').DataTable();
} );
$(document).ready(function() {
$('#table2').DataTable();
} );

	$('#pinGen').click(function(){
		$.ajax({
			url:"<?=base_url('auth/pinGenerate');?>",
			
			success:function(data)
			{
				$('#pin').val(data);
			}
		});
	});



	function condelUser()
	{
		var cnf =confirm('Are you Sure to Delete this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function block()
	{
		var cnf =confirm('Are you Sure to Block this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function unblock()
	{
		var cnf =confirm('Are you Sure to Unblock this User');
		if(cnf)
		{
			return true;
		}else
		{
			return false;
		}
	}
	function walletChange(user,cash,topup)
	{
		$('#userId').val(user);
		$('#cashWallet').val(cash);
		$('#topupWallet').val(topup);
		$('#walletModal').modal('show');
	}
</script>
<style type="text/css">
	.btn-circle{
		border-radius: 50%;
	}
	.Udeactive{
		background: darkred;
		color: #fff;
	}
	.Uactive{
		background: darkgreen;
		color: #fff;
	}
</style>