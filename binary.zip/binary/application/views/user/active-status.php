<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?=$page['page']='My Profile';?> | <?=$this->siteInfo['name'];?></title>
  	<?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
    	<?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
  	<div class="wrapper" id="wrapper">
    	<div class="left-container" id="left-container">
      	<!--========== Sidebar Start =============-->
      		<?php $this->load->view('include/sidebar',$page); ?>
      	<!--========== Sidebar End ===============-->
    	</div>
	    <div class="right-container" id="right-container">
	      	<div class="container-fluid">
		        <?php $this->load->view('include/page-top',$page); ?>
		        <!--//===============Main Container Start=============//-->
		        <div class="row padding-top">
		          <div class="col-lg-12">
          </div>
            <br>
          </div>
           <?php $sponcerName = $this->db->get_where('users',['user_id'=>$this->logged['sponcer_id']])->row_array();?>
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 jumbotron">
                    <!--left col-->
                    <ul class="list-group">
                        <li class="list-group-item active text-muted" contenteditable="false">Profile</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">User Name</strong></span> <?=$this->logged['name'];?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Date Of Registration</strong></span> <?=$this->dbm->dateFormat($this->logged['reg_date']);?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Date Of Activation</strong></span> <?=$this->dbm->dateFormat($this->logged['active_date']);?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Sponcer User Id</strong></span> <?=$this->logged['sponcer_id'];?>.</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Sponcer Name</strong></span> <?=$sponcerName['name'];?>.</li>
                    </ul>
                </div>
                <!--/col-3-->
                   
                </div>
            </div>           
		        </div>
	        <!--//===============Main Container End=============//-->
	      	</div>
	    </div>
  	</div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>
