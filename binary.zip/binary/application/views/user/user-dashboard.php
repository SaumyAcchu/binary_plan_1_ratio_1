<!DOCTYPE html>
<html lang="en">
<head>
    <title><?=$page['page']='Dashboard';?> | <?=$this->siteInfo['name'];?></title>
    <?php $this->load->view('include/header'); ?>
    <style type="text/css">
  .load{
    height:23px;
  }
</style>

</head>
<body>
  <!--===========top nav start=======-->
      <?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
    <div class="wrapper" id="wrapper">
      <div class="left-container" id="left-container">
        <!--========== Sidebar Start =============-->
          <?php $this->load->view('include/sidebar',$page); ?>
          <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/front-dashboard.css'); ?>">
        <!--========== Sidebar End ===============-->
      </div>
      <div class="right-container" id="right-container">
          <div class="container-fluid">
            <?php $this->load->view('include/page-top',$page); ?>
            <!--//===============Main Container Start=============//-->
            <div class="row padding-top">
              <?php if($this->logged['status']==1){
                $color='green'; $fa='fa-check-square-o';
                $status='Active';
              }else {
                $color='red'; $fa='fa-user-times';
                $status='Deactive'; ?>
                <hr>
                <center>Do You Have Pin : <button type="button" id="opnModal" class="btn btn-primary"> Activate Now </button></center><hr><?php
              } 
               ?>
               
                <div class="col-lg-3 col-xs-6" style="height: 150px;">
                    <div class="circle-tile">
                        <a href="<?=base_url('user/explore/my-profile'); ?>"><div class="circle-tile-heading  circle-tile-heading blue" id="head-tile"><i class="fa fa-user fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded"><?=$this->logged['name'];?></div>
                              <h4 class="tile-head"><?=$this->logged['user_id'];?></h4>
                            <a class="circle-tile-footer" href="<?=base_url('user/explore/my-profile'); ?>">More Info <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>
              <div class="col-lg-3 col-xs-6" >
                    <div class="circle-tile ">
                        <a href="javascript:void(0);"><div class="circle-tile-heading <?=$color;?>" id="head-tile"><i class="fa <?=$fa;?> fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content <?=$color;?>">
                              <div class="circle-tile-description text-faded">Status</div>
                              <h3 class="tile-head"><?=$status;?></h3>
                            <a class="circle-tile-footer" href="<?=base_url('user/explore/active-status'); ?>">More Info <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>

                <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile ">
                        <a href="<?=base_url('user/statics/'.base64_encode('directAll/1/My Referrals'));?>"><div class="circle-tile-heading circle-tile-heading blue" id="head-tile"><i class="fa fa-line-chart fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded"> My Referrals </div>
                              <?php $dir=$this->dbm->rowCount('users',['sponcer_id'=>$this->logged['user_id']]); ?>
                              <h3 class="tile-head"><?=$dir;?></h3>
                            <a class="circle-tile-footer" href="<?=base_url('user/statics/'.base64_encode('directAll/1/My Referrals'));?>">More Info <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile">
                        <a href="<?=base_url('user/downLine/'.base64_encode('all'));?>"><div class="circle-tile-heading blue" id="head-tile"><i class="fa fa-sitemap fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded">Down Line</div>
                              <h3 class="tile-head" id="down"><img src="<?=base_url('assets/images/loading.gif');?>" class="load"></h3>
                            <a class="circle-tile-footer" href="<?=base_url('user/downLine/'.base64_encode('all'));?>">Explore Down Line <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>
                </div>
                  <div class="row">
              <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile ">
                        <a href="<?=base_url('user/paymentHistory'); ?>"><div class="circle-tile-heading blue" id="head-tile"><i class="fa fa-google-wallet fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded"> Total Earnings</div>
                              <?php $tE =$this->dbm->totalEarn($this->logged['user_id'])/.9;
                                $DeE = $this->dbm->totalEarn($this->logged['user_id']); 
                                $toalPay = $tE;
                              ?>
                              <h3 class="tile-head"><?=$DeE;?></h3>
                            <a class="circle-tile-footer" href="<?=base_url('user/paymentHistory'); ?>">More Info <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile">
                        <a href="javascript:void(0);"><div class="circle-tile-heading blue" id="head-tile"><i class="fa fa-inr fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded"> Wallet</div>
                              <h3 class="tile-head"><?=number_format($this->logged['wallet'],2);?></h3>
                            <a class="circle-tile-footer" href="javascript:void(0);">More Info <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>
          

          
              

                <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile">
                        <a href="<?=base_url('user/downLine/'.base64_encode('left'));?>"><div class="circle-tile-heading blue" id="head-tile"><i class="fa fa-chevron-circle-left fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile-description text-faded"> Left Users</div>
                              <h3 class="tile-head" id="left"><img src="<?=base_url('assets/images/loading.gif');?>" class="load"></h3>
                            <a class="circle-tile-footer"  href="<?=base_url('user/downLine/'.base64_encode('left'));?>">Explore Left Users <i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>

                <div class="col-lg-3 col-xs-6">
                    <div class="circle-tile">
                        <a href="<?=base_url('user/downLine/'.base64_encode('right'));?>"><div class="circle-tile-heading blue" id="head-tile"><i class="fa fa-chevron-circle-right fa-fw fa-3x"></i></div></a>
                          <div class="circle-tile-content blue">
                              <div class="circle-tile- text-faded"> Right Users</div>
                              <h3 class="tile-head" id="right"><img src="<?=base_url('assets/images/loading.gif');?>" class="load"></h3>
                            <a class="circle-tile-footer" href="<?=base_url('user/downLine/'.base64_encode('right'));?>">Explore Right Users<i class="fa fa-chevron-circle-right"></i></a>
                          </div>
                    </div>
                </div>

               
                <span style="display: none;" id="p1"><?=base_url('stable/join/'.base64_encode($this->logged['user_id']));?></span> 
            </div>
            <div class="row">
            <div class="col-lg-8">

              </div>
              <div class="col-lg-4">
                <div class="panel panel-primary">
                  <div class="panel-heading">
                    <h3 class="panel-title">Latest Announcements</h3>
                  </div>
                  <div class="panel-body" id="news-panel">
                    <div class="list-group"><marquee direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" height="200">
                    <?php if($notice){ $i=1;
                    foreach ($notice as $key => $value){ ?>
                <a onclick="return noticeModal('<?=$this->dbm->dateFormat($value['date']);?>','<?=$value['message'];
                ?>');" href="javascript:void(0);" class="list-group-item"><b><?=$i;?></b> : Date :- <?=$this->dbm->dateFormat($value['date']);?><br><?=substr($value['message'],0,50);?>...</a>
                <a href="#" class="list-group-item"></a>
                    <?php $i++; } } else { ?>
                    <p>No Current Announcements.</p>
                    <?php } ?></marquee>
                      </div>
                  </div>
                </div>  
              </div>
            </div>
           
          <!--//===============Main Container End=============//-->
          </div>
      </div>
    </div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>
 <!-- Bootstrap Modal for Notice -->
  <div class="modal fade" id="noticeModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-body" style="padding: 0px;">
            <div class="panel panel-primary" style="margin-bottom: 0px;">
            <div class="panel-heading">
             <p class="panel-title">Notice
             <button type="button" class="close pull-right" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span></button></p>
            </div>
            <div class="panel-body">
                <div class="list-group">
        <a href="#" class="list-group-item"><b>Issue Date : </b><h5 class="txtred" id="noticeDate"></h5></a>
        <a href="#" class="list-group-item"><b>Message : </b><p id="notice"></p></a>
              </div>
            </div>
        </div>
        </div>
      </div>
    </div>
  </div>
        <!-- Modal End -->
  <script type="text/javascript">
  $(window).on('load',function(){
    $.ajax({
      url:"<?=base_url('user/countDown');?>",
      type:'post',
      dataType:'json',
      success:function(data)
      {
        $('#down').html(data['down']);
        $('#left').html(data['left']);
        $('#right').html(data['right']);
      }
    });
  });
  function noticeModal(date,message)
  {
    $('#noticeModal').modal('show');
    $('#noticeDate').html(date);
    $('#notice').html(message);
  }
  function copyToClipboard(elementId) {
  alert('Link Copied to your Clipboard.');
  // Create a "hidden" input
  var aux = document.createElement("input");

  // Assign it the value of the specified element
  aux.setAttribute("value", document.getElementById(elementId).innerHTML);

  // Append it to the body
  document.body.appendChild(aux);

  // Highlight its content
  aux.select();

  // Copy the highlighted text
  document.execCommand("copy");

  // Remove it from the body
  document.body.removeChild(aux);

}
</script>