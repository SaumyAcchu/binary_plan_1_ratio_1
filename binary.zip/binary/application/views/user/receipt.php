<!DOCTYPE html>
<html lang="en">
<head>
    <title><?=$page['page']='id-card-generate';?> | <?=$this->siteInfo['name'];?></title>
    <?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
      <?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
    <div class="wrapper" id="wrapper">
      <div class="left-container" id="left-container">
        <!--========== Sidebar Start =============-->
          <?php $this->load->view('include/sidebar',$page); ?>
        <!--========== Sidebar End ===============-->
      </div>
      <div class="right-container" id="right-container">
          <div class="container-fluid">
            <?php $this->load->view('include/page-top',$page); ?>
            <!--//===============Main Container Start=============//-->
            <div class="row padding-top">
              <!-- .........................date wize filter data................. -->
            <div class="col-sm-12">
              <button class="btn btn-primary pull-right" id="printId"> Print <i class="fa fa-print"></i></button>
              <hr>
            </div>
            <div class="col-sm-12" id="myDiv">
               <table class="table" cellpadding="4" style="width: 100%; margin-bottom: 0px; ">
                <tbody>
                  <tr>
                      <td class="txtcenter">
                    <center><img src="<?=base_url('uploads/'.$this->siteInfo['image']);?>" height="95" width="260"></center>
                   
                      <h3 style="margin-top: -3px; font-size: 12px;"><?=$this->siteInfo['name'];?></h3>
                     <span style="font-size:12px;"> <?=$this->siteInfo['address'];?></span><br>
                      <span style="font-size:12px;">Email : <?=$this->siteInfo['email'];?>, Website : <?=$this->siteInfo['website'];?></span>
                    </td>
                  </tr>
                  <tr>
                      <td> <hr style="border-top: 2px solid red;">
                     <center> <h1><u>Cash Receipt</u></h1></center>
                          </td>
                  </tr>

                  </table>
               <table>
                    
                    <tr>
                     <td>Receipt No:- OXI<?=$this->logged['id'];?><br></td>
                 </tr>
                 <tr>
                    <td>
                 <br>
                 </td>
                 </tr>
                   <tr>
                       <td>
                           <?php $amt = $this->db->get_where('product_plan',['id'=>$this->logged['product']])->row_array(); ?>
                           
                         Oxijan marketing acknowledge the payment of <b><?=$amt['amount'];?></b>, in words <b><?=$this->dbm->wordAmt($amt['amount']);?> </b> has been received from <b><?=$this->logged['name'];?>, </b> S/O  <b><?=$this->logged['fname'];?>,</b> Address <b><?=$this->logged['address'];?> </b>, the distributer whose user ID <b><?=$this->logged['user_id'];?> </b>is against the purchage of our products.
                       </td>
                   </tr>
               </table>
              
                    <table>
                        <tr><td><br></td></tr>
                       
                   <tr>
                       <td>Place : ___________<br></td>
                                           </tr>
                   <tr>
                       
                        <td>Date : ___________</td>
                   </tr>
                    <tr>
                       <td>http://oxijan.com</td>
                   </tr>
               </table> 
              <!--<p style="margin-left: 153px;"><b style=" ">This is computer generated welcome letter, no signature is required.</b></p>-->
              <!-- <br><br><br> -->
              <!-- <center><p>This is a Computer Generated ID Card</p></center> -->
            </div>      
          </div>
          <!-- All Content End here -->
        </div>
      </div>
    </div>
</body> 
<?php $this->load->view('include/footer.php'); ?>
<script type="text/javascript">
  $("#printId").click(function(){
        var printContents = $("#myDiv").html();
         var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
      var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
      frameDoc.document.write('<html><head><link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/mystyle.css');?>" /></head><body onload="window.print()">' + printContents + '</body></html>');
      frameDoc.document.close();
    });                          
</script>