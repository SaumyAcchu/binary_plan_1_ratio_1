<!DOCTYPE html>
<html lang="en">
<head>
    <title><?=$page['page']='id-card-generate';?> | <?=$this->siteInfo['name'];?></title>
    <?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
      <?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
    <div class="wrapper" id="wrapper">
      <div class="left-container" id="left-container">
        <!--========== Sidebar Start =============-->
          <?php $this->load->view('include/sidebar',$page); ?>
        <!--========== Sidebar End ===============-->
      </div>
      <div class="right-container" id="right-container">
          <div class="container-fluid">
            <?php $this->load->view('include/page-top',$page); ?>
            <!--//===============Main Container Start=============//-->
            <div class="row padding-top">
              <!-- .........................date wize filter data................. -->
            <div class="col-sm-12">
              <button class="btn btn-primary pull-right" id="printId"> Print <i class="fa fa-print"></i></button>
              <hr>
            </div>
            <div class="col-sm-12" id="myDiv">
               <table class="table" cellpadding="4" style="width: 100%; margin-bottom: 0px; ">
                <tbody>
                  <tr>
                      <td class="txtcenter">
                    <center><img src="<?=base_url('uploads/'.$this->siteInfo['image']);?>" height="95" width="260"></center>
                   
                      <h3 style="margin-top: -3px; font-size: 19px; margin-bottom: -4px;"><?=$this->siteInfo['name'];?></h3>
                      <span style="font-size:12px;"><?=$this->siteInfo['address'];?></span><br>
                      <span style="font-size:12px;">Email : <?=$this->siteInfo['email'];?>, Website : <?=$this->siteInfo['website'];?></span>
                    </td>
                  </tr>
                  <tr>
                      <td> <hr style="border-top: 2px solid red;margin-top: -7px;">
                     <center> <h1>Welcome Letter</h1></center>
                          </td>
                  </tr>

                  </table>
               <table style="margin-top: -23px;">
                    <tr>
                     <td>To,</td>
                 </tr>
                    <tr>
                     <td><?=$this->logged['name'];?>,</td>
                 </tr>
                 <tr>
                    <td><?=$this->logged['address'];?>,</td>
                 </tr>
                    <tr>
                    <td>
                 <br>
                 </td>
                 </tr>
                 <tr>
                     <td>Dear User,</td>
                 </tr>
                 <tr>
                    <td>
                 <br>
                 </td>
                 </tr>
                    <tr>
                       <td>
                           Welcome To <?=$this->siteInfo['name'];?>.....!
                       </td>
                   </tr>
                   <tr>
                       <td>
                          We take this opportunity to thank you for your kind consideration and showing interest in our company, Oxijan Marketing Pvt. Ltd. Through this letter, we would like to extend a warm welcome to you as a part of our company, for meeting your financial business needs. We appreciate that you have chosen a recognized company, which is committed to provide excellence and superior professionalism to its clients and customers. 
                       <br>
                       Your member id as specified below is to be used in all your communication with the company. You are requested to verify the accuracy of your Identity and Mailing address.
                       <br>
                       In case, you need any assistance please contact our support team and they will respond to your queries in the best possible ways.
                       </td>
                   </tr>
                  
                   <tr>
                       <td><center><b><br>Your subscription details area as follow</b></center><br></td>
                   </tr>
               </table>
              
                 <table class="table table-bordered" cellpadding="4" style="width: 100%; margin-bottom: 0px; background-color: lightcyan;" border="1" >
                   <tr>
                       <td>
                           <center>User Id:   </center>
                       </td>
                       <td>
                           <center><?=$this->logged['user_id'];?></center>
                       </td>
                   </tr>
                   <tr>
                       <td>
                          <center>  User Name: </center>
                       </td>
                         <td>
                           <center><?=$this->logged['name'];?></center>
                       </td>
                   </tr>
                   <tr>
                       <td>
                          <center> User Mobile No  </center>
                       </td>
                         <td>
                           <center><?=$this->logged['mobile'];?></center>
                       </td>
                   </tr>
                    <tr>
                       <td>
                          <center> User Email :  </center>
                       </td>
                         <td>
                           <center><?=$this->logged['email'];?></center>
                       </td>
                   </tr>
                     <tr>
                       <td>
                         <center>  Date Of Joining :   </center>
                       </td>
                         <td>
                           <center><?=$this->logged['reg_date'];?></center>
                       </td>
                   </tr>
                   <tr>
                       <td>
                        <center>   Date Of Activation :  </center>
                       </td>
                         <td>
                           <center><?=$this->logged['active_date'];?></center>
                       </td>
                   </tr>
               </table>
                    <table>
                   <tr>
                       <td>
                          Once again welcome to <?=$this->siteInfo['name'];?> and congratulation on having taken the first step towards a very prosperous and promissing futer. We are looking forward to have better business prospective in your association!
                       </td>
                   </tr>
                       
                   <tr><br>
                       <td>With Best Regards</td>
                   </tr>
                    <tr>
                       <td>http://oxijan.com</td>
                   </tr>
               </table> 
              <p style="margin-left: 153px;"><b style=" ">This is computer generated welcome letter, no signature is required.</b></p>
              <!-- <br><br><br> -->
              <!-- <center><p>This is a Computer Generated ID Card</p></center> -->
            </div>      
          </div>
          <!-- All Content End here -->
        </div>
      </div>
    </div>
</body> 
<?php $this->load->view('include/footer.php'); ?>
<script type="text/javascript">
  $("#printId").click(function(){
        var printContents = $("#myDiv").html();
         var frame1 = $('<iframe />');
        frame1[0].name = "frame1";
        frame1.css({ "position": "absolute", "top": "-1000000px" });
        $("body").append(frame1);
      var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
        frameDoc.document.open();
      frameDoc.document.write('<html><head><link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/mystyle.css');?>" /></head><body onload="window.print()">' + printContents + '</body></html>');
      frameDoc.document.close();
    });                          
</script>