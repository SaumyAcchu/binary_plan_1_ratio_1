<!DOCTYPE html>
<html lang="en">
<head>
  	<title><?=$page['page']='My Profile';?> | <?=$this->siteInfo['name'];?></title>
  	<?php $this->load->view('include/header'); ?>
</head>
<body>
  <!--===========top nav start=======-->
    	<?php $this->load->view('include/topbar'); ?>
  <!--===========top nav end===========-->
  	<div class="wrapper" id="wrapper">
    	<div class="left-container" id="left-container">
      	<!--========== Sidebar Start =============-->
      		<?php $this->load->view('include/sidebar',$page); ?>
      	<!--========== Sidebar End ===============-->
    	</div>
	    <div class="right-container" id="right-container">
	      	<div class="container-fluid">
		        <?php $this->load->view('include/page-top',$page); ?>
		        <!--//===============Main Container Start=============//-->
		        <div class="row padding-top">
		          <div class="col-lg-12">
              <div class="well well-sm">
                      <div class="row">
                        <div class="col-sm-6 col-md-2">
                          <img title="profile image" class="img-circle img-responsive" src="<?=base_url('uploads/'.$this->logged['image']);?>">
                        </div>
                        <div class="col-sm-6 col-md-7">
                          <h4><i class="glyphicon glyphicon-user"></i> <strong><?=$this->logged['name'];?></strong></h4>
                             <i class="fa fa-vcard-o"> User ID</i> :  <?=$this->logged['user_id'];?><br><i class="fa fa-shopping-cart"> Package</i> :
                             
                              <?php  $status = $this->db->get_where('product_plan',['id'=>$this->logged['product']])->row_array();?>
                             
                             
                             
                             <?=$status['name'];?>
                              <!-- Split button -->
                              <!--<a href="<?=base_url('user/getData/'.base64_encode('users/'.$this->logged['user_id'].'/update-profile'));?>" class="btn btn-success"> Update Profile</a>-->
                          </div>
                          <div class="col-sm-12 col-md-3"><br>
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                  <div class="row">
                                    <div class="col-xs-4">
                                        <i class="fa fa-inr fa-5x"></i>
                                      </div>
                                      <div class="col-xs-8 text-right">
                                        <p class="announcement-heading">Wallet Balanace</p>
                                        <h3 class="announcement-text"><?=number_format($this->logged['wallet'],2);?></h3>
                                      </div>
                                  </div>
                                </div>
                            </div>
                          </div>
                      </div>
                  </div>
          </div>
            <br>
          </div>
            <div class="row">
                <div class="col-sm-3">
                    <!--left col-->
                    <ul class="list-group">
                        <li class="list-group-item active text-muted" contenteditable="false">Profile</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Sponcer ID</strong></span> <?=$this->logged['sponcer_id'];?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Password</strong></span> <?=$this->logged['password'];?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Joined</strong></span> <?=$this->dbm->dateFormat($this->logged['reg_date']);?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Father</strong></span> <?=$this->logged['fname'];?>.</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">DOB</strong></span> <?=$this->logged['dob'];?>.</li>
                    </ul>
                   <div class="panel panel-default">
                      <div class="panel-heading">
                        Account Status
                        </div>
                        <div class="panel-body">
                          <?=($this->logged['status']==1)?'<i style="color:green" class="fa fa-check-square"></i> Yes, Account is <p class="btn btn-success">Active</p>.':'<i style="color:red" class="fa fa-ban"></i> No, Account is <p class="btn btn-danger"> In-active</p>.';?>
                        </div>
                    </div>
                </div>
                <!--/col-3-->
                <div class="col-sm-4">
                    <!--left col-->
                    <ul class="list-group">
                        <li class="list-group-item active text-muted" contenteditable="false">Account Details</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Mobile Number</strong></span> <?=$this->logged['mobile'];?></li>
                         <li class="list-group-item text-right"><span class="pull-left"><strong class="">Email</strong></span> <?=($this->logged['email']!='')?$this->logged['email']:'Not Added Yet';?>.</li>

                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">PAN Number</strong></span><?=($this->logged['pan']!='')?$this->logged['pan']:'Not Added Yet';?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Paytm Account Number</strong></span> <?=($this->logged['paytm']!='')?$this->logged['paytm']:'Not Added Yet';?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Bank Name</strong></span> <?=($this->logged['bank_name']!='')?$this->logged['bank_name']:'Not Added Yet';?>.</li>
                      
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Bank Account Number</strong></span> <?=($this->logged['account_number']!='')?$this->logged['account_number']:'Not Added Yet';?>.</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">IFSC Code</strong></span> <?=($this->logged['ifsc']!='')?$this->logged['ifsc']:'Not Added Yet';?>.</li>
                    </ul>
                </div>
                
                
                <div class="col-sm-5">
                    <!--left col-->
                    <ul class="list-group">
                        <li class="list-group-item active text-muted" contenteditable="false">Nominee Details And Address</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nomini Name</strong></span> <?=$this->logged['nomini_name'];?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nomini Relation</strong></span> <?=($this->logged['nomini_rel']!='')?$this->logged['nomini_rel']:'Not Added Yet';?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Nomini DOB</strong></span> <?=($this->logged['nomini_dob']!='')?$this->logged['nomini_dob']:'Not Active Yet';?></li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Father</strong></span> <?=$this->logged['fname'];?>.</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">DOB</strong></span> <?=$this->logged['dob'];?>.</li>
                        <li class="list-group-item text-right"><span class="pull-left"><strong class="">Permanent Address</strong></span> <?=$this->logged['address'];?>.</li>
                        
                    </ul>
                                  
                </div>

                      
            
            
		        </div>
	        <!--//===============Main Container End=============//-->
	      	</div>
	    </div>
  	</div>
  <!--==========Footer Start=============-->
  <?php $this->load->view('include/footer'); ?>
  <!--==========Footer End=============-->   
</body>
</html>
