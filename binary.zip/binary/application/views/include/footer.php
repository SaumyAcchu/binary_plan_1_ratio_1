<script src="<?=base_url('assetsadmin/js/bootstrap.min.js');?>"></script>
<script src="<?=base_url('assetsadmin/js/jquery.dataTables.min.js');?>"></script>
<script src="<?=base_url('assetsadmin/js/dataTables.bootstrap.min.js');?>"></script>
<script src="<?=base_url('assetsadmin/js/bootstrap-datepicker.js'); ?>"></script>
<script type="text/javascript" src="<?=base_url('assetsadmin/js/templatemo-script.js'); ?>"></script>
<script src="<?=base_url('assetsadmin/js/myscript.js'); ?>"></script>