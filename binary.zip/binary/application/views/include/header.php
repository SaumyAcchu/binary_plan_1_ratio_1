<meta name="google-site-verification" content="-FCO-LU9MOskYuigVWv8n5oqMza_-VIPhQLQoU9bt-E" />	
<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<meta name="author" content="Ocean Infosystem">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="<?=base_url('uploads/'.$this->siteInfo['image']); ?>" type="image/gif" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assetsadmin/css/bootstrap.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assetsadmin/css/bootstrap-datepicker.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assetsadmin/css/dataTables.bootstrap.min.css');?>">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assetsadmin/css/dashboardstyle.css'); ?>">
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://use.fontawesome.com/be653a2bbf.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Courgette|Lobster|Righteous|Ubuntu+Condensed" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?=base_url('assetsadmin/css/mystyle.css'); ?>">
        