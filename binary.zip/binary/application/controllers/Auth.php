<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Auth extends My_Controller
{
	public function __construct()
	{
		parent:: __construct();
		$logged=$this->session->userdata('loggedUser');
		if($logged['access']!='universal')
		{ return redirect('user'); }
		$this->load->model('dbm');
		$this->load->model('comm');
		$this->load->model('reward');
		$this->load->model('fund');
		$this->load->model('repurchase_model');
	}
		public function rewardsganret($value='')
	{
		$userList = $this->dbm->globalSelect('users',['status'=>1]);

		foreach ($userList as $key => $user) {
			$this->reward->rewardstart($user['user_id']);
		}
	}

    public function fundganret($value='')
	{
		$userList = $this->dbm->globalSelect('users',['status'=>1]);

		foreach ($userList as $key => $user) {
			$this->fund->fundstart($user['user_id']);
		}
		return redirect('auth/exploreData/fund/fund');
		
	}
    
	public function getBinary()
	{
    	 $result=$this->dbm->globalSelect('users',['access'=>"limited",'status'=>1]);
    	 $plan = $this->db->get_where('product_plan')->row_array();
     	 foreach ($result as $key => $value) {
     	     
     		$pairs = $this->comm->pairCount($value['user_id']);
     		echo "<pre>";
     		echo $value['user_id'];
     		print_r($pairs);
     	   	if($pairs['left'] && $pairs['right']){
         		if($pairs['left'] >= $pairs['right']){
         		    $possiblePairs = $pairs['right'];
         		}else{
         		    $possiblePairs = $pairs['left'];
         		}
         		
         		$lastTracker = $this->db->limit(1)->order_by('id','DESC')->get_where('binaryincometracker', ['userid'=>$value['user_id']])->row_array();
         		if(!$lastTracker){
         		    $lastTracker = [
         		        'userid' => $value['user_id'],
         		        'left_count' => $pairs['left'],
         		        'right_count' => $pairs['right'],
         		        'pairs' => 0,
         		        'previous_pairs' => 0
         		        ];
         		}
         		
         		$newPairs = ($possiblePairs - $lastTracker['pairs']);

         		$isPaymentLaps = $this->db->get_Where('pairenable')->result_array();

         		if($newPairs <= 0) continue;
         	
         		for($i = $lastTracker['pairs'] + 1; $i <= $possiblePairs; $i++) {
         			$binaryPairIncome = [
         		        'pair' => $i,
         		        'user_id' => $value['user_id'],
         		        ];
         		    if(!in_array($i, array_column($isPaymentLaps, 'pair'))) {
         		    	$binaryPairIncome['amount'] = $plan['binary'];
         		    	$binaryPairIncome['status'] = 1;
         		    	$binaryPairIncome['date'] = date('Y-m-d');
         		    	$binaryPairIncome['type'] = 'PAIR_MATCHING';
         		        
         		    }else{
         		    	$binaryPairIncome['amount'] = 0;
         		    }
                    $this->comm->tds($binaryPairIncome);
         		    $this->db->insert('pair_income', $binaryPairIncome);
         		}
         		
         		$lastTracker = [
         		        'userid' => $value['user_id'],
         		        'left_count' => $pairs['left'],
         		        'right_count' => $pairs['right'],
         		        'pairs' => $possiblePairs,
         		        ];
         		$this->db->insert('binaryincometracker',$lastTracker);
     	   	}
 	    }
 	    return redirect('auth/exploreData/product_plan/level-management');
	}
	
	
	public function userUpgrade($param1='',$param2='',$param3='',$binary='')
	{
			$success=$this->dbm->globalUpdate('users',['user_id'=>$param1],['product'=>$param2,'topup'=>$binary]);
			$success=$this->dbm->globalUpdate('self_upgrade',['id'=>$param3],['status'=>1,'upgrade_date'=>date('Y-m-d')]);
			if($success)
			{
			
			 //   ...............Start Comm.......................
			$data = $this->db->get_where('users',['user_id'=>$param1])->row_array();
			$beforeUp = $this->db->get_where('self_upgrade',['id'=>$param3])->row_array();
			$afterUp = $this->db->get_where('product_plan',['id'=>$beforeUp['old_pakg']])->row_array();
			$bonusComm = $beforeUp['amount']-$afterUp['amount'];
			$bonus = (($bonusComm*5)/100);
		    $res=$this->dbm->getWhere('users',['user_id'=>$data['sponcer_id']]);
		    $comm['user_id']=$data['user_id'];
		    $comm['pin']=$data['pin'];
		    $comm['sponcer_id']=$data['sponcer_id'];
		    $comm['date']=date('Y-m-d');
		    $comm['type']='bonus';
		    $tds=5;
			$comm['beneficiary']=$data['sponcer_id'];
			$deduction['tds']=($bonus*5)/100;
			$deduction['admin']=($bonus*5)/100;
			$deduction['user_id']=$data['user_id'];
			$deduction['date']=date('Y-m-d');
			$deduction['time']=date('H:i:s');
			$deduction['amount']=$bonus;
			$deduction['type']='commission';
			$deduction['admin_percent']=10;
			$deduction['tds_percent']=$tds;
			$left=($bonus-($deduction['admin']+$deduction['tds']));
				if($res['status']==1)
			{
				$wall=$left+$res['wallet'];
				$this->dbm->globalUpdate('users',['user_id'=>$res['user_id']],['wallet'=>$wall]);
				$comm['status']=1;
				$deduction['status']=1;
				$comm['is_credit']=1;
				$deduction['is_credit']=1;
			}else
			{
				$comm['status']=0;
				$deduction['status']=0;
				$comm['is_credit']=0;
				$deduction['is_credit']=0;
			}
			$comm['amount']=($bonus-($deduction['admin']+$deduction['tds']));
			$comm['time']=date('H:i:s');
			$trncId=$this->dbm->transactionNumber();
			$comm['transaction']='C'.$trncId;
            $deduction['amount']=($bonus-($deduction['admin']+$deduction['tds']));
			$deduction['transaction']=$comm['transaction'];
			$this->db->insert('tds',$deduction);
			$this->db->insert('upgrade_comm',$comm);
// 			.............End Commission.................
			$this->setMessage('1','User Upgrade Successfully.');
			}
			else
			{
				$this->setMessage('0','User not Upgrade ! Try Again');
			}
			
		   return redirect('auth/exploreData/self_upgrade/upgrade-users');
	}	
	
	public function FundMatch($table='',$page='')
	{
	    $bonus = $_POST['amount'];
	    $tds = 0; $admin = 0;
	    $user = $this->dbm->globalSelect('fund_income',['reward_level'=>$_POST['type']]);
	    foreach ($user as $key => $value)
		{  
	    $data['user_id'] = $value['user_id'];
	    $data['amount'] = $bonus;
        $data['status'] = 1;
        $data['level'] = $value['reward_level'];
        $data['date'] = date('Y-m-d');
        $data['type'] = 'FUND_COMM';
        $this->comm->tds($data);
        $result =  $this->db->insert('fund_renewal', $data);
        if($result)
		{
			$this->setMessage('1','Data Updated Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Updating Failed ! Try Again');
		}
		 
		}
	    
	   	return redirect('auth/exploreData/fund/fund'); 
	}
	
	
	
	
	public function getAll()
	{
		$num=0;
		$pre=date('Y-m-d',strtotime('previous day'));
		$total=$this->dbm->rowCount('users',['reg_date'=>$pre]);
		$user=$this->dbm->globalSelect('users');
		foreach ($user as $key => $value)
		{
			$left=[]; $right=[];
			$arr['user_id']=$value['user_id'];
			$l=$this->comm->downLeft($value['user_id']);
			foreach ($l as $key => $value1)
			{
				if($value1['reg_date']==$pre)
				{
					$left[]=$value1;
				}
			}
			$r=$this->comm->downRight($value['user_id']);
			foreach ($r as $key => $value2)
			{
				if($value2['reg_date']==$pre)
				{
					$right[]=$value2;
				}
			}
			if(count($left)>count($right))
			{
				$pair=count($right);
			}else
			{
				$pair=count($left);
			}
			$arr['left_count']=count($left);
			$arr['right_count']=count($right);
			$arr['pair']=$pair;
			$arr['date']=$pre;
			$arr['time']=date('H:i:s');
			$arr['joining']=$total;
			$arr['amount']=0;
			$arr['status']=0;
			$arr['is_credit']=0;
			$arr['transaction']=$this->dbm->transactionNumber();
			$arr['left_user']=implode(',',array_column($left, 'user_id'));
			$arr['right_user']=implode(',',array_column($right, 'user_id'));
			$this->dbm->globalInsert('commission',$arr);
			$num=$num+$pair;
			unset($left); unset($right);
			//echo "<pre>"; print_r($arr);
		}
		$amt=($total*500)/$num;
		$this->dbm->globalUpdate('commission',['date'=>$pre],['amount'=>$amt]);
	}

	public function index()
	{
		$result['notice']=$this->dbm->globalSelect('notice');
		$result['recent']=$this->dbm->selectLimit('users',['access'=>'limited'],10);
		//echo "<pre>"; print_r($result); die;
		$this->load->view('admin/admin-dashboard',$result);
	}

	public function explore($page='')
	{
		$this->load->view('admin/'.$page);
	}
	
	public function exploreData($table='',$page='')
	{
		$result['data']=$this->dbm->globalSelect($table);
		$this->load->view('admin/'.$page,$result);
	}

	public function getData($table='',$id='',$page='')
	{
		$result['get_data']=$this->dbm->getWhere($table,['id'=>$id]);
		$this->load->view('admin/'.$page,$result);
	}

	public function updateData($table='',$id='',$page='')
	{
		$data=$_POST;
// 		echo "<pre>";
// 		print_r($_POST);
// 		die;
		$result=$this->dbm->globalUpdate($table,['id'=>$id],$data);
		if($result)
		{
			$this->setMessage('1','Data Updated Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Updating Failed ! Try Again');
		}
		return redirect('auth/exploreData/'.$table.'/'.$page);	
	}

	public function insertData($table='',$page='')
	{
		$data=$_POST;
		$result=$this->dbm->globalInsert($table,$data);
		if($result)
		{
			$this->setMessage('1','Data Inserted Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Inserting Failed ! Try Again');
		}
		return redirect('auth/exploreData/'.$table.'/'.$page);	
	}

	public function deleteData($table='',$id='',$page='')
	{
		$result=$this->dbm->globalDelete($table,['id'=>$id]);
		if($result)
		{
			$this->setMessage('1','Data Deleted Successfully.');
		}
		else
		{
			$this->setMessage('0','Data not Deleted ! Try Again');
		}
		return redirect('auth/exploreData/'.$table.'/'.$page);	
	}

	public function getAllData($str='',$other='')
	{
		$arr=explode('/',base64_decode($str));
		$table=$arr[0]; //DB Table
		$tblField=$arr[1];  //DB Table field
		$matcher=$arr[2];  //Matching Value
		$page=$arr[3];  //Landing Page
		$result['data']=$this->dbm->globalSelect($table,[$tblField=>$matcher]);
		$this->load->view('admin/'.$page,$result);
	}

	public function insertDataWithFile($table='',$page='',$param3='')
	{
		$data=$_POST;
		$a=$_FILES['image']['name'];
		if($a)
		{
			$config = array(
					'upload_path' => "./uploads",
					'allowed_types' => "jpg|png|jpeg",
				);
			$this->load->library('upload',$config);
			$this->upload->do_upload('image');
			$img=$this->upload->data();
			$data['image']=$img['file_name'];
		}
		else
		{
			$data=$_POST;
		}
		//echo '<pre>'; print_r($myres); exit;
		$result=$this->dbm->globalInsert($table,$data);
		if($result)
		{
			$this->setMessage('1','Data Inserted Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Inserting Failed ! Try Again');
		}
		return redirect('auth/exploreData/'.$table.'/'.$page);
	}

	public function updateDataWithFile($table='',$id='',$page='')
	{
		$data=$_POST;
		$a=$_FILES['image']['name'];
		if($a)
		{
			$config = array(
					'upload_path' => "./uploads",
					'allowed_types' => "jpg|png|jpeg",
				);
			$this->load->library('upload',$config);
			$this->upload->do_upload('image');
			$img=$this->upload->data();
			$data['image']=$img['file_name'];
		}
		else
		{
			$data=$_POST;
		}
		//echo '<pre>'; print_r($data); exit;
		$result=$this->dbm->globalUpdate($table,['id'=>$id],$data);
		if($result)
		{
			$this->setMessage('1','Data Updated Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Updating Failed ! Try Again');
		}
		return redirect('auth/exploreData/'.$table.'/'.$page);
	}

	public function setMessage($param1='',$param2='')
	{
		if($param1==1)
		{
			$this->session->set_flashdata('msg',$param2);
			$this->session->set_flashdata('msg_class','alert-success');
		}
		else
		{
			$this->session->set_flashdata('msg',$param2);
			$this->session->set_flashdata('msg_class','alert-danger');
		}
	}

	public function pinGenerate($param1='',$param2='')
	{
		$letter=str_shuffle('1ASHISH3ZX1CVB4N2M8ASD0FG5H5JKLQ3WE9RT5YUI7OP8TIWARI11');
		$str=substr($letter,0,6);
		$digit=strtoupper(uniqid());
		$digit=substr($digit,8);
		$rand=rand(100,999);
		$final=strtoupper($str.$rand.$digit);
		$row=$this->dbm->rowCount('pin',['pin'=>$final]);
		if($row>0)
		{
			$this->pinGenerate();
		}else
		{
			return $final;
		}
	}

	public function checkPin($param1='',$param2='')
	{
		$pin=$_POST['pin'];
		$res=$this->dbm->rowCount('pin',['pin'=>$pin]);
		if($res>0)
		{
			echo 1;
		}else
		{
			echo 0;
		}
	}

	public function sendPin($param1='',$param2='')
	{
		$data=$_POST;
		$user=$this->dbm->rowCount('users',['user_id'=>$data['user_id']]);
		if($user>0)
		{
			$id=$data['req_id'];
			$data['gen_date']=date('Y-m-d');
			$data['gen_time']=date('H:i:s');
			$data['status']=0;
			$data['generate_by']='admin';
			for($i=1;$i<=$data['quantity'];$i++)
			{
				$data['pin']=$this->pinGenerate();
				$this->dbm->pinTransferByAdmin($data,$data['pin']);
				$this->dbm->globalInsert('pin',$data);
			}
			unset($data['req_id']);
			unset($data['generate_by']);
			$data['status']=1;
			$result=$this->dbm->globalUpdate('pin_request',['id'=>$id],$data);
			if($result)
			{
				$this->setMessage('1','PIN Sent Successfully.');
			}
			else
			{
				$this->setMessage('0','PIN sending Failed ! Try Again');
			}
		}else
		{
			$this->setMessage('0','User ID Not Found.');
		}
		return redirect('auth/exploreData/pin_request/pin-management');
	}

	public function deletePin($param1='',$param2='')
	{
		$result=$this->dbm->globalDelete('pin',['id'=>$param1]);
		if($result)
		{
			$this->dbm->globalUpdate('users',['pin'=>$param2],['pin'=>'','status'=>'']);
			$this->dbm->globalUpdate('pin_request',['pin'=>$param2],['pin'=>'','status'=>'']);
			$this->setMessage('1','PIN Deleted Successfully.');
		}
		else
		{
			$this->setMessage('0','PIN not Deleted ! Try Again');
		}
		return redirect('auth/exploreData/pin_request/pin-management');
	}

	public function sendPinDirectUser($param1='',$param2='')
	{
	    $pinid = $this->db->get_where('product_plan')->row_array();
		$data=$_POST;
		$user=$this->dbm->rowCount('users',['user_id'=>$data['user_id']]);
		if($user>0)
		{
			$data['user_id']=strtoupper($data['user_id']);
			$data['gen_date']=date('Y-m-d');
			$data['gen_time']=date('H:i:s');
			$data['status']=0;
			$data['generate_by']='admin';
			$data['product_id'] = $pinid['id'];
			for($i=1;$i<=$data['quantity'];$i++)
			{
				$data['pin']=$this->pinGenerate();
				$this->dbm->pinTransferByAdmin($data,$data['pin']);
				$result=$this->dbm->globalInsert('pin',$data);
			}
			if($result)
			{
				$this->setMessage('1','PIN Sent Successfully.');
			}
			else
			{
				$this->setMessage('0','PIN sending Failed ! Try Again');
			}
		}else
		{
			$this->setMessage('0','User ID Not Found.');
		}
		return redirect('auth/exploreData/pin_request/pin-management');
	}

	public function dailyReport($param1='',$param2='')
	{
		if($param1=='today')
		{
			$condition=array('entry_date'=>date('Y-m-d'));
			$result['data']=$this->dbm->globalSelect('expense_entry',$condition);
			$this->load->view('admin/daily-report',$result);
			//echo '<pre>'; print_r($result); exit;
		}else
		{
			$data=$_POST;
			$result['date']= array('from'=>$data['dateFrom'],'to'=>$data['dateTo']);
			$dateFrom=$data['dateFrom'];
			$dateTo=$data['dateTo'];
			$dateFrom1=new DateTime($dateFrom);
			$new_dateFrom=$dateFrom1->format('Y-m-d');
			$dateTo1=new DateTime($dateTo);
			$new_dateTo=$dateTo1->format('Y-m-d');
			$condition= array('entry_date>='=>$new_dateFrom,'entry_date<='=>$new_dateTo);
			$result['data']=$this->dbm->globalSelect('expense_entry',$condition);
			$this->load->view('admin/daily-report',$result);
		}
	}

	public function expenseManagement($param1='',$param2='')
	{
		if($param1=='add')
		{
			$data=$this->input->post();
			$mdate=$this->input->post('entry_date');
			$myDateTime = new DateTime($mdate);
			$newDateString = $myDateTime->format('Y-m-d');
			$data['entry_date']=$newDateString;
			$result=$this->dbm->globalInsert('expense_entry',$data);
			if($result)
			{
				$this->session->set_flashdata('msg','Data Added Successfully');
				$this->session->set_flashdata('msg_class','alert-success');
			}
			else
			{
				$this->session->set_flashdata('msg','Data Inserting Failed ! Try Again');
				$this->session->set_flashdata('msg_class','alert-success');
			}
			return redirect('auth/expenseManagement');
		}
		if($param1=='expenseReport')
		{
			$data=$_POST;
			$result['date']= array('from'=>$data['dateFrom'],'to'=>$data['dateTo']);
			$dateFrom=$data['dateFrom'];
			$dateTo=$data['dateTo'];
			$branchId=$data['branch_id'];
			$dateFrom1=new DateTime($dateFrom);
			$new_dateFrom=$dateFrom1->format('Y-m-d');
			$dateTo1=new DateTime($dateTo);
			$new_dateTo=$dateTo1->format('Y-m-d');
			$condition= array('entry_date>='=>$new_dateFrom,'entry_date<='=>$new_dateTo);
			$result['branchList']=$this->dbm->globalSelect('branch');
			$result['category']=$this->dbm->globalSelect('expense_category');
			$result['expense_report']=$this->dbm->globalSelect('expense_entry',$condition);
			$result['data']=$this->dbm->globalSelect('expense_entry');
			$this->load->view('admin/expense_management',$result);
		}else
		{
			$result['data']=$this->dbm->globalSelect('expense_entry');
			$result['category']=$this->dbm->globalSelect('expense_category');
			//echo '<pre>'; print_r($result); die;
			$this->load->view('admin/expense_management',$result);
		}
	}

	public function getName($param1='')
	{
		$res=$this->dbm->getName($_POST['user_id']);
		if($res)
		{
			echo $res;
		}else
		{
			echo 0;
		}
	}

	public function pinHistory($param1='',$param2='')
	{
		$data['genBy']=strtoupper($param1);
		$data['active']=$this->dbm->globalSelect('pin',['generate_by'=>$param1,'status'=>1]);
		$data['deactive']=$this->dbm->globalSelect('pin',['generate_by'=>$param1,'status'=>0]);
		$this->load->view('admin/pin-history',$data);
	}

	public function quickReply($param1='',$param2='')
	{
		if($param1=='get')
		{
			$res['data']=$this->dbm->globalSelect('query',['sender!='=>'Admin']);
			$this->load->view('admin/user-query',$res);
		}else
		{
			$data=$_POST;
			$result=$this->dbm->globalInsert('query',$data);
			if($result)
			{
				$this->setMessage('1','Replied Successfully.');
			}
			else
			{
				$this->setMessage('0','Replying Failed ! Try Again');
			}
			return redirect('auth/quickReply/get');
		}
	}

	public function queryDelete($table='',$id='',$page='')
	{
		$this->dbm->globalDelete($table,['query_id'=>$id]);
		$result=$this->dbm->globalDelete($table,['id'=>$id]);
		if($result)
		{
			$this->setMessage('1','Mesage Deleted Successfully.');
		}
		else
		{
			$this->setMessage('0','Message not Deleted ! Try Again');
		}
		return redirect('auth/quickReply/get');	
	}

	public function userBlock($param1='',$param2='')
	{
		if($param2=='block')
		{
			$success=$this->dbm->globalUpdate('users',['user_id'=>$param1],['block'=>1]);
			if($success)
			{
				$this->setMessage('1','User Blocked Successfully.');
			}
			else
			{
				$this->setMessage('0','User not Blocked ! Try Again');
			}
			
		}
		if($param2=='unblock')
		{
			$success=$this->dbm->globalUpdate('users',['user_id'=>$param1],['block'=>0]);
			if($success)
			{
				$this->setMessage('1','User unblocked Successfully.');
			}
			else
			{
				$this->setMessage('0','User not Unblocked ! Try Again');
			}
		}
		return redirect('auth/exploreData/users/user-management');
	}
	
	
	public function pairEnable($param1='',$param2='')
	{
		if($param2=='enable')
		{
			$success=$this->dbm->globalUpdate('pairenable',['id'=>$param1],['payment'=>1]);
			if($success)
			{
				$this->setMessage('1','Pair Enable Successfully.');
			}
			else
			{
				$this->setMessage('0','Pair not Enable ! Try Again');
			}
			
		}
		if($param2=='disable')
		{
			$success=$this->dbm->globalUpdate('pairenable',['id'=>$param1],['payment'=>0]);
			if($success)
			{
				$this->setMessage('1','Disable Successfully.');
			}
			else
			{
				$this->setMessage('0','Pair not Disable ! Try Again');
			}
		}
		return redirect('auth/exploreData/product_plan/level-management');
	}

	public function payoutReport($param1='',$param2='')
	{
		$data=$_POST;
		$result['date']= array('from'=>$data['dateFrom'],'to'=>$data['dateTo']);
		$dateFrom=$data['dateFrom'];
		$dateTo=$data['dateTo'];
		$dateFrom1=new DateTime($dateFrom);
		$new_dateFrom=$dateFrom1->format('Y-m-d');
		$dateTo1=new DateTime($dateTo);
		$new_dateTo=$dateTo1->format('Y-m-d');
		$condition= array('date>='=>$new_dateFrom,'date<='=>$new_dateTo,'status'=>"1");
		$condition2= array('date>='=>$new_dateFrom,'date<='=>$new_dateTo);
		$condition1= array('date>='=>$new_dateFrom,'date<='=>$new_dateTo,'paidAmt!='=>"0");
		$result['pairMatch']=$this->dbm->globalSelect('pair_income',$condition2);
		$result['fund']=$this->dbm->globalSelect('fund_renewal',$condition2);
		$result['referral']=$this->dbm->globalSelect('commission',$condition);
		$result['india']=$this->dbm->globalSelect('india_income',$condition);
		$result['rewards']=$this->dbm->globalSelect('reward_income',$condition);
		$result['upgrade']=$this->dbm->globalSelect('pairmaching',$condition1);
		$this->load->view('admin/payout-report',$result);
		// echo '<pre>'; print_r($result); exit;
	}

    public function payoutReportWidhra($param1='',$param2='')
	{
		$data=$_POST;
		$result['date']= array('from'=>$data['dateFrom'],'to'=>$data['dateTo']);
		$dateFrom=$data['dateFrom'];
		$dateTo=$data['dateTo'];
		$dateFrom1=new DateTime($dateFrom);
		$new_dateFrom=$dateFrom1->format('Y-m-d');
		$dateTo1=new DateTime($dateTo);
		$new_dateTo=$dateTo1->format('Y-m-d');
		$condition= array('date>='=>$new_dateFrom,'date<='=>$new_dateTo);
		$result['referral']=$this->dbm->globalSelect('withdraw',['date>='=>$new_dateFrom,'date<='=>$new_dateTo]);
		$this->load->view('admin/widhrawal-statement',$result);
		// echo '<pre>'; print_r($result); exit;
	}
	public function getDataAjax($str='',$id='',$page='')
	{
		$result=$this->dbm->getWhere($_POST['table'],['user_id'=>$_POST['user_id']]);
		echo json_encode($result);
	}

	public function withdrawRequest($param1='',$param2='')
	{
		$result['type']=$param1;
		if($param1=='paid')
		{
			$result['bank']=$this->dbm->globalSelect('withdraw',['payment_mode'=>'Bank','status'=>1]);
			$result['paytm']=$this->dbm->globalSelect('withdraw',['payment_mode'=>'Paytm','status'=>1]);
			$this->load->view('admin/withdraw-request',$result);
		}
		if($param1=='unpaid')
		{
			$result['bank']=$this->dbm->globalSelect('withdraw',['payment_mode'=>'Bank','status'=>0]);
			$result['paytm']=$this->dbm->globalSelect('withdraw',['payment_mode'=>'Paytm','status'=>0]);
			$this->load->view('admin/withdraw-request',$result);
		}
	}

	public function withdrawPayment($param1='',$param2='')
	{
		$data=$_POST;
		$data['status']=1;
		$data['paid_date']=date('Y-m-d');
		$data['paid_time']=date('H:i:s');
		$trncId=$this->dbm->transactionNumber();
		$comm['data']='W'.$trncId;
		$data['transaction']=$comm['data'];
		$res=$this->dbm->globalUpdate('withdraw',['id'=>$data['id']],$data);
		if($res)
		{
			$this->setMessage('1','Paid Successfully.');
		}
		else
		{
			$this->setMessage('0','Action Failed ! Try Again');
		}
		return redirect('auth/withdrawRequest/unpaid');
	}
	
	public function activePinViaTopup($param1='',$param2='')
	{
		$data['date']=date('Y-m-d');
		$data['time']=date('H:i:s');
		$data['activated_account']=strtoupper($_POST['user_id']);
		$data['status']=1;
		$user['active_time']=$data['time'];
		$user['active_date']=$data['date'];
		$user['status']=1;
		$user['pin']=$_POST['pin'];
		$valid=$this->dbm->rowCount('pin',['pin'=>$user['pin'],'status'=>1]);
		if($valid>0)
		{
			$this->setMessage('0','This PIN is Already Activated, Try Again!.');
		}else
		{
		    $usr=$this->dbm->getWhere('users',['user_id'=>strtoupper($_POST['user_id'])]);
// 			
			if($usr) 
			{
			    $res=$this->dbm->globalUpdate('pin',['pin'=>$_POST['pin']],$data);
				$this->dbm->globalUpdate('users',['user_id'=>strtoupper($_POST['user_id'])],$user);
				$usr=$this->dbm->getWhere('users',['user_id'=>strtoupper($_POST['user_id'])]);
				$this->comm->agentCommission($usr);
				
				$this->setMessage('1','Account Activated Successfully.');
			}else
			{
				$this->setMessage('0','Account Not Activated, Try Again!.');
			}
		}
		return redirect('auth/getAllData/'.base64_encode('pin/generate_by/admin/pin-management'));
	}
	
	public function selfPay()
	{
		$data=$_POST;
		$data['status']=1;
		$data['paid_date']=date('Y-m-d');
		$data['paid_time']=date('H:i:s');
		$trncId=$this->dbm->transactionNumber();
		$data['transaction']='W'.$trncId;
		$data['date']=date('Y-m-d');
		$data['time']=date('H:i:s');
		$res=$this->dbm->globalInsert('withdraw',$data);
		if($res)
		{
			$user=$this->dbm->getWhere('users',['user_id'=>$data['user_id']]);
			$amt=($user['wallet']-$data['amount']);
			$this->dbm->globalUpdate('users',['user_id'=>$data['user_id']],['wallet'=>$amt]);
			$this->setMessage('1','Paymet Send Successfully.');
		}
		return redirect('auth/explore/self-pay');
	}
	public function getPair($param1='')
	{
		$res=$this->dbm->rowCount('pairenable',['pair'=>$_POST['id']]);
		if($res>0)
		{
			echo 1;
		}else
		{
			echo 0;
		}
	}
		public function addproduct($value='')
	{
		$data = $_POST;
		$a=$_FILES['image']['name'];
		if($a)
		{
			$config = array(
					'upload_path' => "./uploads",
					'allowed_types' => "jpg|png|jpeg",
				);
			$this->load->library('upload',$config);
			$this->upload->do_upload('image');
			$img=$this->upload->data();
			$data['image']=$img['file_name'];
		}
		else
		{
			$data['image']='blue.png';
		}
		$res=$this->dbm->productregistration($data);
		if ($res) {
			$usr=$this->dbm->getWhere('product',['id'=>$res]);	
			$this->setMessage('1','Product Create Successfully.');
			return redirect('auth/explore/add-product');	
		}else{
			return redirect('auth');
		}
	}

	public function Shipping_insert()
	{
	
		$data=$_POST;
		
		//print_r($data); exit();
		$b['supplier_id']=$this->input->post('supplier_id');
			$_SESSION['id']=$b;

		$b['date']=$this->input->post('date');
		$b['invoiceno']=$this->input->post('invoiceno');
		
		$this->load->model('dbm');
		$invoice_id=$this->dbm->lasinsert('product_parchase',$b);
		if($invoice_id)
         {
	         	$i =0;
		    	foreach ($data['product_id'] as $key => $value)
		    	 {
					$product_id =$value."<br>";
					
					 $product_id =$data['product_id'][$i];
				     $product_hsn =$data['product_hsn'][$i];
				      $batch_no =$data['batch_no'][$i];
				       $product_qty =$data['product_qty'][$i];
				       $product_price =$data['product_price'][$i];
				       $product_igst =$data['product_igst'][$i];
				       $product_sgst =$data['product_sgst'][$i];
				       $product_cgst =$data['product_cgst'][$i];

		$data1 = array('suplier_id	'=>$invoice_id,'product_id'=>$product_id,'product_hsn'=>$product_hsn,'batch_no'=>$batch_no,'product_qty'=>$product_qty,'product_price'=>$product_price,'product_igst'=>$product_igst,'product_sgst'=>$product_sgst,'product_cgst'=>$product_cgst);
				    $this->load->model('dbm');
					$aaaa=$this->dbm->comlast('purchase_data',$data1);
				   	$i++; 
		          }

		         	return redirect('auth/invoceSlip');
		         }
            }
      public function addsupplier($value='')
	{
		$data = $_POST;		
		$res=$this->dbm->suplierregistration($data);
		if ($res) {
			$usr=$this->dbm->getWhere('supplier',['id'=>$res]);	
			$this->setMessage('1','Supplier Create Successfully.');
			return redirect('auth/explore/add-supplier');	
		}else{
			return redirect('auth');
		}
	}

	public function parchaseProduct($value='')
	{
		$data = $_POST;
		$i =  0;
		foreach ($data['product_id'] as $key => $value) {
			$datapro['supplier_id'] = $data['supplier_id'];
			$datapro['product_id'] = $data['product_id'][$i];
			$datapro['product_hsn'] = $data['product_hsn'][$i];
			$datapro['batch_no'] = $data['batch_no'][$i];
			$datapro['product_qty'] = $data['product_qty'][$i];
			$datapro['product_price'] = $data['product_price'][$i];
			$datapro['product_igst'] = $data['product_igst'][$i];
			$datapro['product_sgst'] = $data['product_sgst'][$i];
			$datapro['product_cgst'] = $data['product_cgst'][$i];
			$datapro['invoiceno'] = $data['invoiceno'];
			$datapro['date'] = date('Y-m-d');
			$i++;
			 print_r($datapro);

				if ($datapro['product_qty']>0 && $datapro['product_price']!='') 
				{
					$datapro['total_price'] = ($datapro['product_price']*$datapro['product_qty'])+($datapro['product_price']*$datapro['product_qty']*($datapro['product_igst']+$datapro['product_sgst']+$datapro['product_cgst']))/100;
				$parchase_id = $this->dbm->globalInsert('product_parchase',$datapro);
				
				$pro = $this->dbm->getWhere('product',['id'=>$datapro['product_id']]);
			$proqty = $pro['qty']+$datapro['product_qty'];
			
			$this->dbm->globalUpdate('product',['id'=>$datapro['product_id']],['qty'=>$proqty]);
			  }


		}

		if (isset($parchase_id)) {

			
		
			return redirect('auth/invoceSlip/'.$parchase_id.'/'.$data['supplier_id'].'/'.$data['invoiceno']);

		}else{
			echo "Not Inserted! Try Again";
		}


		die();



		
	}
	public function invoceSlip($parchaseId='',$param='',$pam='')
	{
	    $res['product']=$this->dbm->globalSelect('product_parchase');
	  $res['bookingresltd'] = $this->dbm->globalSelect('product_parchase',['invoiceno'=>$pam]);
		$res['suplierdtl'] = $this->dbm->getWhere('supplier',['supplier_id'=>$param]);
		$res['invoice'] = $this->dbm->getWhere('product_parchase',['invoiceno'=>$pam]);
		$this->load->view('admin/parchase-invoic',$res);
	}
	public function invoceSlipedit($parchaseId='',$param='',$pam='')
	{
	    $res['result']=$this->dbm->getWhere('product_parchase',['id'=>$param]);
		$res['suplierdtl'] = $this->dbm->getWhere('supplier',['supplier_id'=>$parchaseId]);
		$res['invoice'] = $this->dbm->getWhere('product_parchase',['invoiceno'=>$pam]);
		$this->load->view('admin/parchase-invoic-edit',$res);
	}   


	public function invoceSlipeditupdate($parchaseId='',$param='')
	{
		$data=$_POST;
	    $result=$this->dbm->globalUpdate('product_parchase',['id'=>$parchaseId],$data);
		if($result)
		{
			$this->setMessage('1','Data Updated Successfully.');
		}
		else
		{
			$this->setMessage('0','Data Updating Failed ! Try Again');
		}
		return redirect('auth/exploreData/product_parchase/parchase-details');
	} 
    
    public function ParchageInvoice()
    {
        
        $res['product']=$this->dbm->globalSelect('product_parchase');
	    $res['bookingresltd'] = $this->dbm->globalSelect('product_parchase',['supplier_id'=>$param]);
		$res['suplierdtl'] = $this->dbm->getWhere('supplier',['supplier_id'=>$param]);
		$this->load->view('admin/parchase-invoic-report',$res);
    }
    public function purchaseHistory($param1='',$param2='')
	{
		if($param1=='today')
		{
			$condition=array('date'=>date('Y-m-d'));
			$result['data']=$this->dbm->globalSelect('booking',$condition);
			$this->load->view('admin/purchase-history',$result);
			//echo '<pre>'; print_r($result); exit;
		}else
		{
			$data=$_POST;
			$result['date']= array('user_id'=>$data['user_id'],'from'=>$data['dateFrom'],'to'=>$data['dateTo']);
			$dateFrom=$data['dateFrom'];
			$dateTo=$data['dateTo'];
			$dateFrom1=new DateTime($dateFrom);
			$new_dateFrom=$dateFrom1->format('Y-m-d');
			$dateTo1=new DateTime($dateTo);
			$new_dateTo=$dateTo1->format('Y-m-d');
			$condition= array('user_id'=>$data['user_id'],'date>='=>$new_dateFrom,'date<='=>$new_dateTo);
			$result['data']=$this->dbm->globalSelect('booking',$condition);
			// echo "<pre>";print_r($result);die();
			$this->load->view('admin/purchase-history',$result);
		}
	}

	public function salesHistory($param1='',$param2='')
	{
		if($param1=='today')
		{
			$condition=array('date'=>date('Y-m-d'));
			$result['data']=$this->dbm->globalSelect('booking',$condition);
			$this->load->view('admin/sales-history',$result);
			//echo '<pre>'; print_r($result); exit;
		}else
		{
			$data=$_POST;
			$result['date']= array('from'=>$data['dateFrom'],'to'=>$data['dateTo']);
			$dateFrom=$data['dateFrom'];
			$dateTo=$data['dateTo'];
			$dateFrom1=new DateTime($dateFrom);
			$new_dateFrom=$dateFrom1->format('Y-m-d');
			$dateTo1=new DateTime($dateTo);
			$new_dateTo=$dateTo1->format('Y-m-d');
			$condition= array('date>='=>$new_dateFrom,'date<='=>$new_dateTo);
			$result['data']=$this->dbm->globalSelect('booking',$condition);
			// echo "<pre>";print_r($result);die();
			$this->load->view('admin/sales-history',$result);
		}
	}
	public function pandingBookingSlip($bookingId='')
	{
		$bookres = $this->dbm->getWhere('booking_panding',['id'=>$bookingId]);
		if (!empty($bookres)) {
		$res['bookingId'] = $bookingId;
		$res['bookingreslt'] = $bookres;
		$res['userdtl'] = $this->dbm->getWhere('users',['user_id'=>$bookres['user_id']]);
		$res['bookingDtl'] = $this->dbm->globalSelect('booking_details_panding',['booking_id'=>$bookres['id']]);
		$this->load->view('admin/print-panding-booking',$res);
		}
		else
		{
		return redirect('auth');
		}
	}
    public function BookingSlipcencelled($param1='',$param2='')
    {
      $date = date('d-m-Y');
      $bookres = $this->dbm->getWhere('booking_panding',['id'=>$param1]);
      $res = $this->dbm->getWhere('users',['user_id'=>$bookres['user_id']]);
      $result = $this->dbm->getwhere('booking_details_panding',['id'=>$param2]);
      $totalcv=$bookres['total_cv']-$result['total_cv'];
      $totalcvamt=$bookres['total_price']-$result['total_dp'];
      $booking_panding = $this->dbm->globalUpdate('booking_panding',['id'=>$param1['id']],['total_cv'=>$totalcv,'total_price'=>$totalcvamt]);
      $update = $this->dbm->globalUpdate('booking_details_panding',['id'=>$param2],['is_cancelled'=>1,'canclled_date'=>$date]);
      $product = $this->dbm->getwhere('product',['id'=>$result['product_id']]);
      $quan = $product['qty']+$result['qty'];
      $update = $this->dbm->globalUpdate('product',['id'=>$product['id']],['qty'=>$quan]);
       if($update)
                {
                    $this->session->set_flashdata('msg','Cancelled Item Sussessfully');
                    $this->session->set_flashdata('msg_class','alert-success');
                }
                else
                {
                    $this->session->set_flashdata('msg','Action Faild! try Again');
                    $this->session->set_flashdata('msg_class','alert-danger');
                }
      $msg ="Dear ".$res['name']." Your Order ".$product['name']." has been cancelled on :".$date.  "http://myarastustores.com";
      $mobile = $res['mobile'];
      // $this->db_model->sendSms($mobile,$msg);
      redirect('auth/pandingBookingSlip/'.$param1);
    }
	public function pandingBookingSlipcencelled($bookingId='')
	{
		$bookres = $this->dbm->getWhere('booking_panding',['id'=>$bookingId]);
		if (!empty($bookres)) {
		$res['bookingId'] = $bookingId;
		$res['bookingreslt'] = $bookres;
		$res['userdtl'] = $this->dbm->getWhere('users',['user_id'=>$bookres['user_id']]);
		$res['bookingDtl'] = $this->dbm->globalSelect('booking_details_panding',['booking_id'=>$bookres['id']]);
		
		$this->load->view('admin/print-panding-booking-ca',$res);
		}else{
			return redirect('auth');
		}
	}

	public function aprovedOrder($data='')
	{
		$this->load->model('repurchase_model');
		$data = $_POST;
		$bookingdata = $this->dbm->getWhere('booking_panding',['id'=>$data['bookingId']]);
		$pandingBookingid = $bookingdata['id'];
		unset($bookingdata['id']);
		unset($bookingdata['current']);
		$booking_id = $this->dbm->globalInsert('booking',$bookingdata);	
		if (isset($booking_id)) {
		$pandingBookingDtl = $this->dbm->globalSelect('booking_details_panding',['booking_id'=>$pandingBookingid],['is_cancelled'=>'0']);
			foreach ($pandingBookingDtl as $items) 
			{
				unset($items['id']);
				unset($items['booking_id']);
				$items['booking_id'] = $booking_id;
				$this->dbm->globalInsert('booking_details',$items);					
			}
			// die();
			
			$repurchasedata['user_id'] = $bookingdata['user_id'];
			$repurchasedata['booking_id'] = $booking_id;
			$repurchasedata['totalcv'] = $bookingdata['total_cv'];
			$repurchasedata['total_price'] = $bookingdata['total_price'];
			$this->repurchase_model->repurchaseCommission($repurchasedata);
			$this->dbm->globalDelete('booking_panding',['id'=>$pandingBookingid]);

			$this->setMessage('1','Booking updated Successfully.');
			return redirect('auth/bookingSlip/'.$booking_id);
		}
	}
 public function bookingSlip($bookingId='')
	{
		$bookres = $this->dbm->getWhere('booking',['id'=>$bookingId]);
		if (!empty($bookres)) {
		$res['bookingreslt'] = $bookres;
		$res['userdtl'] = $this->dbm->getWhere('users',['user_id'=>$bookres['user_id']]);
		$res['bookingDtl'] = $this->dbm->globalSelect('booking_details',['booking_id'=>$bookres['id']]);
		
		// echo "<pre>";print_r($res); die();
		$this->load->view('admin/print-booking',$res);
		}else{
			return redirect('auth');
		}
	}


    
}
