<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends My_Controller {

	
	public function index()
	{
		$this->load->view('website/home');
	}
	public function explore($param1='',$param2='')
	{
		$this->load->view('website/'.$param1);
	}
	public function registration()
	{
		echo "<pre>";
		$config = [
					'upload_path' 		=> './uploads',
					'allowed_types'		=> 'jpg|png|gif|jpeg',
				  ];

		$this->load->library('upload',$config);		// $this->upload->initialize($config);
		$this->load->library('form_validation');		
		if($this->upload->do_upload('image'))
		{
			$post=$this->input->post();
			unset($post['submit']);
			$img = $this->upload->data();
			$post['image_path'] = $img['file_name'];
			
			$successMessage="Registration is successful";	
			$this->session->set_flashdata('feedback',$successMessage);
   			$this->session->set_flashdata('feedback_class','alert-success');		
			redirect('welcome/explore/magazine');
		}
		else
		{
			$failureMessage="Registration is Faild";	
			$this->session->set_flashdata('feedback',$failureMessage);
			$this->session->set_flashdata('feedback_class','alert-danger');
			redirect('welcome/explore/magazine');

		}

		



		

	}
}
