<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stable extends MY_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('dbm');
		$this->load->model('comm');
	}

    public function explore($page='')
	{
		$this->load->view($page);
	}
	public function join($param1='',$param2='')
	{
		$id=base64_decode($param1);
		$row['sponcer_data']=$this->dbm->getWhere('users',['user_id'=>$id]);
		if($row['sponcer_data'])
		{
			$this->load->view('user/user-registration',$row);
		}else
		{
			$join['joinLink']='This Link Seems to be expire or not activated.';
			$this->load->view('user/success-message',$join);
		}
		//$this->load->view('user/user-registration');
	}

	public function joinWithPin($param1='',$param2='')
	{
		$str=base64_decode($param1);
		$arr=explode('/',$str);
		$row['sponcer_data']=$this->dbm->getWhere('users',['user_id'=>$arr[0]]);
		$row['pin']=$arr[1];
		if($row['sponcer_data'])
		{
			$this->load->view('user/user-registration',$row);
		}else
		{
			$join['joinLink']='This Link Seems to be expire or not activated.';
			$this->load->view('user/success-message',$join);
		}
		//$this->load->view('user/user-registration');
	}

	public function treeView($id='')
	{
		$data['userID']=base64_decode($id);
		$this->load->view('tree-view',$data);
	}

	public function logout()
	{
		$this->session->unset_userdata('loggedUser');
		session_destroy();
		return redirect('login');
	}
		public function UsNamevedidation()
	{
	      $email=$_POST['email1'];
         $result=$this->dbm->rowC('users',['user_id'=>$email]);
	}
	
	
	public function emailvedidation()
	{
	     $email=$_POST['email1'];
         $result=$this->dbm->rowC('users',['email'=>$email]);
	}
	
		public function panvedidation()
	{
	     $email=$_POST['email1'];
         $result=$this->dbm->rowC('users',['pan'=>$email]);
	}
		public function mobilevedidation()
	{
	     $email=$_POST['email1'];
         $result=$this->dbm->rowC('users',['mobile'=>$email]);
	}
	

public function getUserTree(){
	?>
	<div class="hv-wrapper">
                <?php
                $d11=$d12=$d13=$d14=$d21=$d22=$d23=$d24=$d31=$d32=$d33=$d34=$d35=$d36=$d37=$d38=$d211=$d221=$d231=$d241=$d212=$d222=$d232=$d242=$d213=$d223=$d233=$d243=null;
                
                $user_id = $_POST['id'];
                if($user_id == ''){
                    echo "Please enter user id";
                    die;
                }
                // .............................................
                
                
                
        unset($_SESSION['dList']);
		$_SESSION['dList']=[];
		$list=[];
		$id=$this->logged['user_id'];
		$this->comm->downList($id);
		$list=$_SESSION['dList'];
        foreach ($list as $key => $value)
			{
                if($value['user_id']==$user_id){
                   
                $arr = $this->db->get_where('users',['user_id'=> $user_id], 1)->row_array();
                $arr1 = $this->db->get_where('users',['parent'=> $user_id], 4)->result_array();
                
                // .................................................
               
        
                
                if(isset($arr1[0])){
                    $d11 = $arr1[0];
                    $arr21 = $this->db->get_where('users',['parent'=> $d11['user_id']], 4)->result_array();
                    if(isset($arr21[0])){
                        $d21 = $arr21[0];
                    }
                    if(isset($arr21[1])){
                        $d22 = $arr21[1];
                    }
                    if(isset($arr21[2])){
                        $d23 = $arr21[2];
                    }
                    if(isset($arr21[3])){
                        $d24 = $arr21[3];
                    }
                }
                    
                if(isset($arr1[1])){
                    $d12 = $arr1[1];
                    $arr22 = $this->db->get_where('users',['parent'=> $d12['user_id']], 4)->result_array();


                    if(isset($arr22[0])){
                        $d211 = $arr22[0];
                    }
                    if(isset($arr22[1])){
                        $d221 = $arr22[1];
                    }
                    if(isset($arr22[2])){
                        $d231 = $arr22[2];
                    }
                    if(isset($arr22[3])){
                        $d241 = $arr22[3];
                    }
                }

                  if(isset($arr1[2])){
                    $d13 = $arr1[2];
                    $arr23 = $this->db->get_where('users',['parent'=> $d13['user_id']], 4)->result_array();

                    if(isset($arr23[0])){
                        $d212 = $arr23[0];
                    }
                    if(isset($arr23[1])){
                        $d222 = $arr23[1];
                    }
                    if(isset($arr23[2])){
                        $d232 = $arr23[2];
                    }
                    if(isset($arr23[3])){
                        $d242 = $arr23[3];
                    }
                }
                if(isset($arr1[3])){
                    $d14 = $arr1[3];
                    $arr24 = $this->db->get_where('users',['parent'=> $d14['user_id']], 4)->result_array();

                    if(isset($arr24[0])){
                        $d213 = $arr24[0];
                    }
                    if(isset($arr24[1])){
                        $d223 = $arr24[1];
                    }
                    if(isset($arr24[2])){
                        $d233 = $arr24[2];
                    }
                    if(isset($arr24[3])){
                        $d243 = $arr24[3];
                    }
                }

                 // echo "<pre>"; print_r($arr1); die();
                ?>
                <!-- Key component -->
                <div class="hv-item">

                    <div class="hv-item-parent">
                        <div class="person">
                             <?php if($arr['status']==1 && ($arr['pan']!="" || $arr['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($arr['status']==1 && ($arr['pan']=="" && $arr['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($arr['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                            <p class="name">
                               <a href="#" onclick="getTreeUPer('<?= $arr['sponcer_id'];?>')">UPPER</a>
                                <br>
                               <?= $arr['name']." (".$arr['user_id'].")"; ?>
                               
                            </p>
                             
                        </div>
                   </div>

                    <?php if($d11) { ?>
                    <div class="hv-item-children">

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d11['status']==1 && ($d11['pan']!="" || $d11['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d11['status']==1 && ($d11['pan']=="" && $d11['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d11['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d11['user_id'];?>')"><?= $d11['name']." (".$d11['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d11['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d21){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d21['status']==1 && ($d21['pan']!="" || $d21['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d21['status']==1 && ($d21['pan']=="" && $d21['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d21['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d21['user_id'];?>')"><?= $d21['name']." (".$d21['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d21['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d22){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d22['status']==1 && ($d22['pan']!="" || $d22['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d22['status']==1 && ($d22['pan']=="" && $d22['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d22['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d22['user_id'];?>')"><?= $d22['name']." (".$d22['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d22['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d23){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d23['status']==1 && ($d23['pan']!="" || $d23['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d23['status']==1 && ($d23['pan']=="" && $d23['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d23['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d23['user_id'];?>')"><?= $d23['name']." (".$d23['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d23['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d24){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d24['status']==1 && ($d24['pan']!="" || $d24['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d24['status']==1 && ($d24['pan']=="" && $d24['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d24['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d24['user_id'];?>')"><?= $d24['name']." (".$d24['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d24['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                        <?php if($d12) { ?>
                       

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                         <?php if($d12['status']==1 && ($d12['pan']!="" || $d12['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d12['status']==1 && ($d12['pan']=="" && $d12['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d12['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d12['user_id'];?>')"><?= $d12['name']." (".$d12['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d12['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d211){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d211['status']==1 && ($d211['pan']!="" || $d211['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d211['status']==1 && ($d211['pan']=="" && $d211['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d211['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d211['user_id'];?>')"><?= $d211['name']." (".$d211['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d211['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d221){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d221['status']==1 && ($d221['pan']!="" || $d221['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d221['status']==1 && ($d221['pan']=="" && $d221['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d221['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d221['user_id'];?>')"><?= $d221['name']." (".$d221['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d221['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d231){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d231['status']==1 && ($d231['pan']!="" || $d231['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d231['status']==1 && ($d231['pan']=="" && $d231['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d231['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d231['user_id'];?>')"><?= $d231['name']." (".$d231['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d231['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d241){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d241['status']==1 && ($d241['pan']!="" || $d241['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d241['status']==1 && ($d241['pan']=="" && $d241['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d241['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d241['user_id'];?>')"><?= $d241['name']." (".$d241['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d241['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                         <?php } ?>
                        <!-- ///////////////Start d13////////////////////// -->

                                                <?php if($d13) { ?>
                       

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d13['status']==1 && ($d13['pan']!="" || $d13['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d13['status']==1 && ($d13['pan']=="" && $d13['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d13['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d13['user_id'];?>')"><?= $d13['name']." (".$d13['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d13['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d212){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d212['status']==1 && ($d212['pan']!="" || $d212['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d212['status']==1 && ($d212['pan']=="" && $d212['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d212['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d212['user_id'];?>')"><?= $d212['name']." (".$d212['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d212['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d222){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d222['status']==1 && ($d222['pan']!="" || $d222['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d222['status']==1 && ($d222['pan']=="" && $d222['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d222['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d222['user_id'];?>')"><?= $d222['name']." (".$d222['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d222['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d232){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d232['status']==1 && ($d232['pan']!="" || $d232['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d232['status']==1 && ($d232['pan']=="" && $d232['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d232['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d232['user_id'];?>')"><?= $d232['name']." (".$d232['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d232['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d242){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                   <?php if($d242['status']==1 && ($d242['pan']!="" || $d242['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d242['status']==1 && ($d242['pan']=="" && $d242['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d242['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d242['user_id'];?>')"><?= $d242['name']." (".$d242['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d242['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                      


                        <!-- .............end14................... -->
                        <?php } ?>

                         <!-- ///////////////Start d14////////////////////// -->

                                                <?php if($d14) { ?>
                      

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d14['status']==1 && ($d14['pan']!="" || $d14['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d14['status']==1 && ($d14['pan']=="" && $d14['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d14['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d14['user_id'];?>')"><?= $d14['name']." (".$d14['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d14['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d213){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d213['status']==1 && ($d213['pan']!="" || $d213['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d213['status']==1 && ($d213['pan']=="" && $d213['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d213['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d213['user_id'];?>')"><?= $d213['name']." (".$d213['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d213['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d223){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d223['status']==1 && ($d223['pan']!="" || $d223['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d223['status']==1 && ($d223['pan']=="" && $d223['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d223['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d223['user_id'];?>')"><?= $d223['name']." (".$d223['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d223['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d233){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d233['status']==1 && ($d233['pan']!="" || $d233['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d233['status']==1 && ($d233['pan']=="" && $d233['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d233['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d233['user_id'];?>')"><?= $d233['name']." (".$d233['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d233['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d243){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d243['status']==1 && ($d243['pan']!="" || $d243['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d243['status']==1 && ($d243['pan']=="" && $d243['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d243['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d243['user_id'];?>')"><?= $d243['name']." (".$d243['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d243['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                      


                        <!-- .............end14................... -->
                        <?php } ?>

                        
                    </div>
                    <?php } ?>
                </div>

            </div>
	<?php
	}
	else  "This User_id Not Exits In Your Tree";
    }
               
 }
   public function getUserTreeTree(){
	?>
	<div class="hv-wrapper">
                 <?php
                $d11=$d12=$d13=$d14=$d21=$d22=$d23=$d24=$d31=$d32=$d33=$d34=$d35=$d36=$d37=$d38=$d211=$d221=$d231=$d241=$d212=$d222=$d232=$d242=$d213=$d223=$d233=$d243=null;
                
                $user_id = $_POST['id'];
                
                if($user_id == ''){
                    echo "Please enter user id";
                    die;
                }
                // .............................................
                
                $arr = $this->db->get_where('users',['user_id'=> $user_id], 1)->row_array();
                $arr1 = $this->db->get_where('users',['parent'=> $user_id], 4)->result_array();
                
                // .................................................
               
        
                
               if(isset($arr1[0])){
                    $d11 = $arr1[0];
                    $arr21 = $this->db->get_where('users',['parent'=> $d11['user_id']], 4)->result_array();
                    if(isset($arr21[0])){
                        $d21 = $arr21[0];
                    }
                    if(isset($arr21[1])){
                        $d22 = $arr21[1];
                    }
                    if(isset($arr21[2])){
                        $d23 = $arr21[2];
                    }
                    if(isset($arr21[3])){
                        $d24 = $arr21[3];
                    }
                }
                    
                if(isset($arr1[1])){
                    $d12 = $arr1[1];
                    $arr22 = $this->db->get_where('users',['parent'=> $d12['user_id']], 4)->result_array();


                    if(isset($arr22[0])){
                        $d211 = $arr22[0];
                    }
                    if(isset($arr22[1])){
                        $d221 = $arr22[1];
                    }
                    if(isset($arr22[2])){
                        $d231 = $arr22[2];
                    }
                    if(isset($arr22[3])){
                        $d241 = $arr22[3];
                    }
                }

                  if(isset($arr1[2])){
                    $d13 = $arr1[2];
                    $arr23 = $this->db->get_where('users',['parent'=> $d13['user_id']], 4)->result_array();

                    if(isset($arr23[0])){
                        $d212 = $arr23[0];
                    }
                    if(isset($arr23[1])){
                        $d222 = $arr23[1];
                    }
                    if(isset($arr23[2])){
                        $d232 = $arr23[2];
                    }
                    if(isset($arr23[3])){
                        $d242 = $arr23[3];
                    }
                }
                if(isset($arr1[3])){
                    $d14 = $arr1[3];
                    $arr24 = $this->db->get_where('users',['parent'=> $d14['user_id']], 4)->result_array();

                    if(isset($arr24[0])){
                        $d213 = $arr24[0];
                    }
                    if(isset($arr24[1])){
                        $d223 = $arr24[1];
                    }
                    if(isset($arr24[2])){
                        $d233 = $arr24[2];
                    }
                    if(isset($arr24[3])){
                        $d243 = $arr24[3];
                    }
                }

                 // echo "<pre>"; print_r($arr1); die();
                ?>
                <!-- Key component -->
                <div class="hv-item">

                    <div class="hv-item-parent">
                        <div class="person">
                             <?php if($arr['status']==1 && ($arr['pan']!="" || $arr['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($arr['status']==1 && ($arr['pan']=="" && $arr['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($arr['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$arr['user_id']; ?>','<?=$arr['reg_date']; ?>','<?=$arr['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                           <p class="name">
                               
                               <?php if($this->logged['user_id']==$arr['user_id'])
                               {?>
                               <a href="#" onclick="getTreeUPer('<?= $arr['sponcer_id'];?>')"></a>
                                <br>
                               <?= $arr['name']." (".$arr['user_id'].")"; ?>
                               <?php }else{?>
                               
                               <a href="#" onclick="getTreeUPer('<?= $arr['sponcer_id'];?>')">UPPER</a>
                                <br>
                               <?= $arr['name']." (".$arr['user_id'].")"; ?>
                               <?php } ?>
                            </p>
                             
                        </div>
                    </div>

                    <?php if($d11) { ?>
                    <div class="hv-item-children">

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d11['status']==1 && ($d11['pan']!="" || $d11['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d11['status']==1 && ($d11['pan']=="" && $d11['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d11['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d11['user_id']; ?>','<?=$d11['reg_date']; ?>','<?=$d11['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d11['user_id'];?>')"><?= $d11['name']." (".$d11['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d11['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d21){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d21['status']==1 && ($d21['pan']!="" || $d21['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d21['status']==1 && ($d21['pan']=="" && $d21['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d21['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d21['user_id']; ?>','<?=$d21['reg_date']; ?>','<?=$d21['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d21['user_id'];?>')"><?= $d21['name']." (".$d21['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d21['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d22){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d22['status']==1 && ($d22['pan']!="" || $d22['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d22['status']==1 && ($d22['pan']=="" && $d22['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d22['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d22['user_id']; ?>','<?=$d22['reg_date']; ?>','<?=$d22['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d22['user_id'];?>')"><?= $d22['name']." (".$d22['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d22['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d23){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d23['status']==1 && ($d23['pan']!="" || $d23['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d23['status']==1 && ($d23['pan']=="" && $d23['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d23['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d23['user_id']; ?>','<?=$d23['reg_date']; ?>','<?=$d23['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d23['user_id'];?>')"><?= $d23['name']." (".$d23['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d23['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d24){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d24['status']==1 && ($d24['pan']!="" || $d24['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d24['status']==1 && ($d24['pan']=="" && $d24['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d24['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d24['user_id']; ?>','<?=$d24['reg_date']; ?>','<?=$d24['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d24['user_id'];?>')"><?= $d24['name']." (".$d24['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d24['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                        <?php if($d12) { ?>
                      
                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                         <?php if($d12['status']==1 && ($d12['pan']!="" || $d12['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d12['status']==1 && ($d12['pan']=="" && $d12['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d12['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d12['user_id']; ?>','<?=$d12['reg_date']; ?>','<?=$d12['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d12['user_id'];?>')"><?= $d12['name']." (".$d12['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d12['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d211){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d211['status']==1 && ($d211['pan']!="" || $d211['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d211['status']==1 && ($d211['pan']=="" && $d211['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d211['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d211['user_id']; ?>','<?=$d211['reg_date']; ?>','<?=$d211['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d211['user_id'];?>')"><?= $d211['name']." (".$d211['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d211['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d221){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d221['status']==1 && ($d221['pan']!="" || $d221['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d221['status']==1 && ($d221['pan']=="" && $d221['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d221['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d221['user_id']; ?>','<?=$d221['reg_date']; ?>','<?=$d221['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d221['user_id'];?>')"><?= $d221['name']." (".$d221['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d221['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d231){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d231['status']==1 && ($d231['pan']!="" || $d231['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d231['status']==1 && ($d231['pan']=="" && $d231['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d231['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d231['user_id']; ?>','<?=$d231['reg_date']; ?>','<?=$d231['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d231['user_id'];?>')"><?= $d231['name']." (".$d231['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d231['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d241){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d241['status']==1 && ($d241['pan']!="" || $d241['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d241['status']==1 && ($d241['pan']=="" && $d241['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d241['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d241['user_id']; ?>','<?=$d241['reg_date']; ?>','<?=$d241['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d241['user_id'];?>')"><?= $d241['name']." (".$d241['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d241['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                         <?php } ?>
                        <!-- ///////////////Start d13////////////////////// -->

                                                <?php if($d13) { ?>
                       

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d13['status']==1 && ($d13['pan']!="" || $d13['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d13['status']==1 && ($d13['pan']=="" && $d13['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d13['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d13['user_id']; ?>','<?=$d13['reg_date']; ?>','<?=$d13['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d13['user_id'];?>')"><?= $d13['name']." (".$d13['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d13['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d212){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d212['status']==1 && ($d212['pan']!="" || $d212['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d212['status']==1 && ($d212['pan']=="" && $d212['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d212['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d212['user_id']; ?>','<?=$d212['reg_date']; ?>','<?=$d212['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d212['user_id'];?>')"><?= $d212['name']." (".$d212['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d212['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d222){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d222['status']==1 && ($d222['pan']!="" || $d222['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d222['status']==1 && ($d222['pan']=="" && $d222['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d222['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d222['user_id']; ?>','<?=$d222['reg_date']; ?>','<?=$d222['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d222['user_id'];?>')"><?= $d222['name']." (".$d222['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d222['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d232){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d232['status']==1 && ($d232['pan']!="" || $d232['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d232['status']==1 && ($d232['pan']=="" && $d232['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d232['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d232['user_id']; ?>','<?=$d232['reg_date']; ?>','<?=$d232['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d232['user_id'];?>')"><?= $d232['name']." (".$d232['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d232['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d242){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                   <?php if($d242['status']==1 && ($d242['pan']!="" || $d242['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d242['status']==1 && ($d242['pan']=="" && $d242['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d242['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d242['user_id']; ?>','<?=$d242['reg_date']; ?>','<?=$d242['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d242['user_id'];?>')"><?= $d242['name']." (".$d242['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d242['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                      


                        <!-- .............end14................... -->
                        <?php } ?>

                         <!-- ///////////////Start d14////////////////////// -->

                                                <?php if($d14) { ?>
                       

                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <?php if($d14['status']==1 && ($d14['pan']!="" || $d14['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d14['status']==1 && ($d14['pan']=="" && $d14['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d14['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d14['user_id']; ?>','<?=$d14['reg_date']; ?>','<?=$d14['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                        <p class="name">
                                              <a href="#" onclick="getTree('<?= $d14['user_id'];?>')"><?= $d14['name']." (".$d14['user_id'].")"; ?></a>
                                            
                                            <br>
                                <?= $d14['place'];?>
                             
                                        </p>
                                    </div>
                                </div>
                                
                                <?php if($d213){ ?>
                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d213['status']==1 && ($d213['pan']!="" || $d213['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d213['status']==1 && ($d213['pan']=="" && $d213['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d213['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d213['user_id']; ?>','<?=$d213['reg_date']; ?>','<?=$d213['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d213['user_id'];?>')"><?= $d213['name']." (".$d213['user_id'].")"; ?></a>
                                                     <br>
                                <?= $d213['place'];?>   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        
                                    <?php if($d223){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d223['status']==1 && ($d223['pan']!="" || $d223['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d223['status']==1 && ($d223['pan']=="" && $d223['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d223['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d223['user_id']; ?>','<?=$d223['reg_date']; ?>','<?=$d223['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d223['user_id'];?>')"><?= $d223['name']." (".$d223['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d223['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d233){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                     <?php if($d233['status']==1 && ($d233['pan']!="" || $d233['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d233['status']==1 && ($d233['pan']=="" && $d233['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d233['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d233['user_id']; ?>','<?=$d233['reg_date']; ?>','<?=$d233['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d233['user_id'];?>')"><?= $d233['name']." (".$d233['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d233['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                    <?php if($d243){ ?>
                                    <div class="hv-item-child">
                                        <!-- Key component -->
                                        <div class="hv-item">
            
                                            <div class="hv-item-child">
                                                <div class="person">
                                                    <?php if($d243['status']==1 && ($d243['pan']!="" || $d243['adharno']!="")){ ?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d243['status']==1 && ($d243['pan']=="" && $d243['adharno']=="")){ ?>
                            
                            <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: green;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } if($d243['status']==0){?>
                             <img src="<?=base_url();?>tree/images/CORS.png" alt="" style="background-color: red;" onmouseover="mykkfunction('<?=$d243['user_id']; ?>','<?=$d243['reg_date']; ?>','<?=$d243['sponcer_id']; ?>','00')" onmouseout="myfunction1()">
                            <?php } ?>
                                                    <p class="name">
                                                        <a href="#" onclick="getTree('<?= $d243['user_id'];?>')"><?= $d243['name']." (".$d243['user_id'].")"; ?></a>
                                                        
                                                        <br>
                                <?= $d243['place'];?>
                                                    </p>
                                                </div>
                                            </div>
                                            

                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>

                      


                        <!-- .............end14................... -->
                        <?php } ?>

                        
                    </div>
                    <?php } ?>
                </div>

            </div>
	<?php
               
 }
 
 public function countDownSearch()
	{
		$right=[]; $left=[]; $down=[];
		unset($_SESSION['dList']);
		$_SESSION['dList']=[];
		$id=$_POST['user_id'];
		$this->comm->downListRR($id);
		$down=$_SESSION['dList'];
		$lu=$this->dbm->getWhere('users',['place'=>'Left','parent'=>$id]);
		if($lu)
		{
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$this->comm->downListRR($lu['user_id']);
			$left=$_SESSION['dList'];
			array_unshift($left, $lu['user_id']);
		}
		$ru=$this->dbm->getWhere('users',['place'=>'Right','parent'=>$id]);
		if($ru)
		{
			unset($_SESSION['dList']);
			$_SESSION['dList']=[];
			$this->comm->downListRR($ru['user_id']);
			$right=$_SESSION['dList'];
			array_unshift($right, $ru['user_id']);
		}
		$arr['down']=count($down);
		$arr['left']=count($left);
		$arr['right']=count($right);	
		echo json_encode($arr);
	}
	public function countAmt()
	{
	    $id=$_POST['user_id'];
	    $user = $this->db->get_Where('users',['user_id'=>$id])->row_array();
        $data = $this->db->get_Where('product_plan',['id'=>$user['product']])->row_array();
        $ru['amount'] = $data['amount'];
        echo json_encode($ru);
	}
}
