<?php
class MY_Controller extends CI_Controller
{
	public $logged;
	public $siteInfo;
	function __construct()
	{
		parent:: __construct();
		$comp=$this->db->get_where('company',['id'=>1])->row_array();
		$this->siteInfo=$comp;
		if($logged=$this->session->userdata('loggedUser'))
		{
			$user=$this->db->get_where('users',['id'=>$logged['id']])->row_array();
			$this->logged=$user;
		}
		date_default_timezone_set('Asia/Kolkata');
		$this->load->model('dbm');
		$this->load->model('comm');
		$this->load->model('reward');
		$this->comm->autoPayout();
		
		$date=date('Y-m-d');
		$valid1=$this->dbm->rowCount('pairmaching',['date'=>$date]);
 		if ($valid1<1) {
            $this->comm->repurchase_incom();
  	         
		 }
		$valid2=$this->dbm->rowCount('sponcer_tracker',['date'=>$date]);
 		if ($valid2<1) {
            $this->comm->Spon_incom();
  	         
		 }
		 
		if((date('D')=="Mon")){
      	$date=date('Y-m-d');
		$valid5=$this->dbm->rowCount('withdraw',['date'=>$date]);
		if ($valid5<1) {
  	         //$this->comm->closeNow();
		  }
       }
		
		//$this->commission_model->royality();
		// if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 300))
	 //    {
	 //      // last request was more than 30 minutes ago
	 //      session_unset();     // unset $_SESSION variable for the run-time 
	 //      session_destroy();   // destroy session data in storage
	 //    }
	 //    $_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp
	}

}